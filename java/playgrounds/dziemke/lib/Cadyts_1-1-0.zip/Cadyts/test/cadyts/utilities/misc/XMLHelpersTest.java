/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import cadyts.utilities.misc.XMLHelpers.Extractor;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class XMLHelpersTest {

	@Test
	public void double2intExtractorTest() {
		assertEquals(0, XMLHelpers.DOUBLE2INT_EXTRACTOR.extract("0.2"));
		assertEquals(-1, XMLHelpers.DOUBLE2INT_EXTRACTOR.extract("-1.3"));
		assertEquals(99, XMLHelpers.DOUBLE2INT_EXTRACTOR.extract("99"));
		assertEquals(-4711, XMLHelpers.DOUBLE2INT_EXTRACTOR.extract("-4711"));
	}

	private static final Extractor<Double> DOUBLE_EXTRACTOR = new Extractor<Double>() {
		public Double extract(final String item) {
			return Double.parseDouble(item);
		}
	};

	@Test
	public void testExtractItemsStringExtractorOfT() {
		final String line = " \t-1.5 \t 0.0\t 1.5 \t ";
		final List<Double> expected = Arrays.asList(-1.5, 0.0, 1.5);
		assertEquals(expected, XMLHelpers.extractItems(line, DOUBLE_EXTRACTOR));
	}

	@Test
	public void testExtractItemsString() {
		final String line = "This is a test.";
		final List<String> expected = Arrays.asList("This", "is", "a", "test.");
		assertEquals(expected, XMLHelpers.extractItems(line));
	}

	@Test
	public void testWriteAttr() throws Exception {
		final String name = "testfile8923749952123349634";
		if (new File(name).exists()) {
			fail("file " + name + " already exists");
		}

		final PrintWriter writer = new PrintWriter(name);
		XMLHelpers.writeAttr("element", -12.34, writer);
		writer.flush();
		writer.close();

		final BufferedReader reader = new BufferedReader(new FileReader(name));
		final String line = reader.readLine();
		reader.close();
		assertEquals("element=\"-12.34\" ", line);

		(new File(name)).delete();
	}

	@Test
	public void testAppendAttr() {
		final StringBuffer result = new StringBuffer();
		XMLHelpers.appendAttr("element", 71276, result);
		assertEquals("element=\"71276\" ", result.toString());
	}
}
