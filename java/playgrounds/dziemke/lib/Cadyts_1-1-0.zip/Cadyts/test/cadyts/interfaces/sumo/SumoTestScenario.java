/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */
package cadyts.interfaces.sumo;

import static cadyts.interfaces.sumo.SumoFlowLoader.EDGE_ELEM;
import static cadyts.interfaces.sumo.SumoFlowLoader.END_ATTR;
import static cadyts.interfaces.sumo.SumoFlowLoader.ENTERED_ATTR;
import static cadyts.interfaces.sumo.SumoFlowLoader.ID_ATTR;
import static cadyts.interfaces.sumo.SumoFlowLoader.INTERVAL_ELEM;
import static cadyts.interfaces.sumo.SumoFlowLoader.START_ATTR;
import static cadyts.interfaces.sumo.SumoPopulationHandler.CHOICEPROB_ATTR;
import static cadyts.interfaces.sumo.SumoPopulationHandler.DEPART_ATTR;
import static cadyts.interfaces.sumo.SumoPopulationHandler.EDGES_ATTR;
import static cadyts.interfaces.sumo.SumoPopulationHandler.EXITTIMES_ATTR;
import static cadyts.interfaces.sumo.SumoPopulationHandler.FROMTAZ_ATTR;
import static cadyts.interfaces.sumo.SumoPopulationHandler.ROUTE_ELEM;
import static cadyts.interfaces.sumo.SumoPopulationHandler.TOTAZ_ATTR;
import static cadyts.interfaces.sumo.SumoPopulationHandler.VEHICLEID_ATTR;
import static cadyts.interfaces.sumo.SumoPopulationHandler.VEHICLE_ELEM;
import static cadyts.utilities.misc.XMLHelpers.writeAttr;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import cadyts.calibrators.filebased.xml.XMLPopulationFileReader;
import cadyts.demand.PlanStep;
import cadyts.utilities.misc.DynamicData;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class SumoTestScenario {

	// -------------------- CONSTANTS --------------------

	static final String PATH = "testdata/sumo/";

	// INIT PARAMETERS

	static final String MEAS_FILE = PATH + "meas.xml" + "," + PATH
			+ "emptyMeas.xml";
	static final String DEMANDSCALE = "2";
	static final String VARSCALE = "1.0";
	static final String MINSTDDEV = "5";
	static final String RANDOM_SEED = "071276";
	static final String REGRINERTIA = "0.95";
	static final String PROPASSIGN = "false";
	static final String PREP_ITS = "5";
	static final String FREEZE_ITS = "50";
	static final String BINSIZE_S = "300";
	static final String CENTERREGR = "false";
	static final String DEBUG = "false";
	static final String BRUTEFORCE = "false";
	static final String OVERRIDETT = "true";
	static final String FMAPREFIX = PATH + "od";
	static final String[] INIT_PARAMS = new String[] { SumoController.INIT,
			SumoController.MEASFILE_KEY, MEAS_FILE,
			SumoController.VARSCALE_KEY, VARSCALE,
			SumoController.MINCOUNTSTDDEV_KEY, MINSTDDEV,
			SumoController.RNDSEED_KEY, RANDOM_SEED,
			SumoController.REGRINERTIA_KEY, REGRINERTIA,
			SumoController.PROPASSIGN_KEY, PROPASSIGN,
			SumoController.FREEZEIT_KEY, FREEZE_ITS,
			SumoController.BINSIZE_KEY, BINSIZE_S,
			SumoController.DEMANDSCALE_KEY, DEMANDSCALE,
			SumoController.CENTERREGR_KEY, CENTERREGR,
			SumoController.DEBUGMODE_KEY, DEBUG, SumoController.BRUTEFORCE_KEY,
			BRUTEFORCE, SumoController.OVERRIDETT_KEY, OVERRIDETT,
			SumoController.FMAPREFIX_KEY, FMAPREFIX };

	// CHOICE PARAMETERS

	static final String CHOICE_SET_FILE = PATH + "choiceset.xml," + PATH
			+ "emptyChoiceSet.xml";
	static final String CHOICE_FILE = PATH + "choices.xml";
	static final String OD_FILE = PATH + "odmatrix.xml";
	static final String[] CHOICE_PARAMS = new String[] { SumoController.CHOICE,
			SumoController.CHOICESETFILE_KEY, CHOICE_SET_FILE,
			SumoController.CHOICEFILE_KEY, CHOICE_FILE };

	// UPDATE PARAMETERS

	static final String SIM_RESULTS_FILE = PATH + "simresults.xml";
	static final String FLOW_FILE = PATH + "flows.txt";
	static final String[] UPDATE_PARAMS = new String[] { SumoController.UPDATE,
			SumoController.NETFILE_KEY, SIM_RESULTS_FILE,
			SumoController.FLOWFILE_KEY, FLOW_FILE };

	// -------------------- MEMBERS --------------------

	List<Double> flowRoute1_veh = new ArrayList<Double>();
	List<Double> flowRoute2_veh = new ArrayList<Double>();

	// -------------------- SIMULATED SIMULATION --------------------

	double popSize = 1000;

	private void writeChoiceSet() throws IOException {
		final PrintWriter writer = new PrintWriter(PATH + "choiceset.xml");

		writer.write("<route-alternatives>");
		writer.println();

		for (int n = 0; n < this.popSize; n++) {

			writer.write("  <");
			writer.write(VEHICLE_ELEM);
			writer.write(" ");
			writeAttr(VEHICLEID_ATTR, Integer.toString(n), writer);
			writeAttr(DEPART_ATTR, "0", writer);
			writeAttr(FROMTAZ_ATTR, "FROM", writer);
			writeAttr(TOTAZ_ATTR, "TO", writer);
			writer.write(">");
			writer.println();

			writer.write("    <");
			writer.write(ROUTE_ELEM);
			writer.write(" ");
			writeAttr(EDGES_ATTR, "0 1 3", writer);
			writeAttr(EXITTIMES_ATTR, "60 120 150", writer);
			writeAttr(CHOICEPROB_ATTR, "0.5", writer);
			writer.write("/>");
			writer.println();

			writer.write("    <");
			writer.write(ROUTE_ELEM);
			writer.write(" ");
			writeAttr(EDGES_ATTR, "0 2 3", writer);
			writeAttr(EXITTIMES_ATTR, "60 120 150", writer);
			writeAttr(CHOICEPROB_ATTR, "0.5", writer);
			writer.write("/>");
			writer.println();

			writer.write("  </");
			writer.write(VEHICLE_ELEM);
			writer.write(">");
			writer.println();
		}

		writer.write("</route-alternatives>");
		writer.println();

		writer.flush();
		writer.close();
	}

	private void writeNetworkConditions() throws IOException {

		int cnt1 = 0;
		int cnt2 = 0;

		final XMLPopulationFileReader<SumoAgent> reader = new XMLPopulationFileReader<SumoAgent>();
		final DynamicData<String> travelTimes = null;
		SumoPopulationHandler populationHandler = new SumoPopulationHandler(
				travelTimes, 1.0);
		reader.setPopulationHandler(populationHandler);
		for (SumoAgent agent : reader.getPopulationSource(CHOICE_FILE)) {
			final Iterator<PlanStep<String>> it = agent.getPlans().get(0)
					.iterator();
			if (it.hasNext()) {
				final PlanStep<String> step = it.next();
				if ("1".equals(step.getLink())) {
					cnt1++;
				} else if ("2".equals(step.getLink())) {
					cnt2++;
				}
			}
		}

		final PrintWriter writer = new PrintWriter(SIM_RESULTS_FILE);

		final int linkTT_s = 1;

		writer.append("<netstats>");
		writer.println();

		// INTERVAL 1

		writer.append("  <");
		writer.append(INTERVAL_ELEM);
		writer.append(" ");
		writeAttr(START_ATTR, "0", writer);
		writeAttr(END_ATTR, "300", writer);
		writer.append(">");
		writer.println();

		writer.append("    <");
		writer.append(EDGE_ELEM);
		writer.append(" ");
		writeAttr(ID_ATTR, "1", writer);
		writeAttr(ENTERED_ATTR, cnt1, writer);
		writeAttr(SumoFlowLoader.TT_ATTR, linkTT_s, writer);
		writer.append("/>");
		writer.println();

		writer.append("    <");
		writer.append(EDGE_ELEM);
		writer.append(" ");
		writeAttr(ID_ATTR, "2", writer);
		writeAttr(ENTERED_ATTR, cnt2, writer);
		writeAttr(SumoFlowLoader.TT_ATTR, linkTT_s, writer);
		writer.append("/>");
		writer.println();

		writer.append("    <");
		writer.append(EDGE_ELEM);
		writer.append(" ");
		writeAttr(ID_ATTR, "3", writer);
		writeAttr(ENTERED_ATTR, cnt1 + cnt2, writer);
		writeAttr(SumoFlowLoader.TT_ATTR, linkTT_s, writer);
		writer.append("/>");
		writer.println();

		writer.append("  </");
		writer.append(INTERVAL_ELEM);
		writer.append(">");
		writer.println();

		// INTERVAL 2

		writer.append("  <");
		writer.append(INTERVAL_ELEM);
		writer.append(" ");
		writeAttr(START_ATTR, "300", writer);
		writeAttr(END_ATTR, "600", writer);
		writer.append(">");
		writer.println();

		writer.append("    <");
		writer.append(EDGE_ELEM);
		writer.append(" ");
		writeAttr(ID_ATTR, "1", writer);
		writeAttr(ENTERED_ATTR, 0, writer);
		writeAttr(SumoFlowLoader.TT_ATTR, linkTT_s, writer);
		writer.append("/>");
		writer.println();

		writer.append("    <");
		writer.append(EDGE_ELEM);
		writer.append(" ");
		writeAttr(ID_ATTR, "2", writer);
		writeAttr(ENTERED_ATTR, 0, writer);
		writeAttr(SumoFlowLoader.TT_ATTR, linkTT_s, writer);
		writer.append("/>");
		writer.println();

		writer.append("    <");
		writer.append(EDGE_ELEM);
		writer.append(" ");
		writeAttr(ID_ATTR, "3", writer);
		writeAttr(ENTERED_ATTR, 0, writer);
		writeAttr(SumoFlowLoader.TT_ATTR, linkTT_s, writer);
		writer.append("/>");
		writer.println();

		writer.append("  </");
		writer.append(INTERVAL_ELEM);
		writer.append(">");
		writer.println();

		// INTERVAL 3

		writer.append("  <");
		writer.append(INTERVAL_ELEM);
		writer.append(" ");
		writeAttr(START_ATTR, "600", writer);
		writeAttr(END_ATTR, "900", writer);
		writer.append(">");
		writer.println();

		writer.append("    <");
		writer.append(EDGE_ELEM);
		writer.append(" ");
		writeAttr(ID_ATTR, "1", writer);
		writeAttr(ENTERED_ATTR, 0, writer);
		writeAttr(SumoFlowLoader.TT_ATTR, linkTT_s, writer);
		writer.append("/>");
		writer.println();

		writer.append("    <");
		writer.append(EDGE_ELEM);
		writer.append(" ");
		writeAttr(ID_ATTR, "2", writer);
		writeAttr(ENTERED_ATTR, 0, writer);
		writeAttr(SumoFlowLoader.TT_ATTR, linkTT_s, writer);
		writer.append("/>");
		writer.println();

		writer.append("    <");
		writer.append(EDGE_ELEM);
		writer.append(" ");
		writeAttr(ID_ATTR, "3", writer);
		writeAttr(ENTERED_ATTR, 0, writer);
		writeAttr(SumoFlowLoader.TT_ATTR, linkTT_s, writer);
		writer.append("/>");
		writer.println();

		writer.append("  </");
		writer.append(INTERVAL_ELEM);
		writer.append(">");
		writer.println();

		writer.append("</netstats>");
		writer.println();

		writer.flush();
		writer.close();

		this.flowRoute1_veh.add(new Double(cnt1));
		this.flowRoute2_veh.add(new Double(cnt2));
	}

	public void run() throws IOException {

		SumoController.main(INIT_PARAMS);

		for (int it = 0; it < 50; it++) {

			this.writeChoiceSet();
			SumoController.main(CHOICE_PARAMS);

			this.writeNetworkConditions();
			SumoController.main(UPDATE_PARAMS);
		}
	}

	// public static void main(String[] args) throws IOException,
	// ClassNotFoundException {
	// final SumoTestScenario test = new SumoTestScenario();
	// test.run();
	// System.out.println(test.flowRoute1_veh);
	// System.out.println(test.flowRoute2_veh);
	// }
}
