/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.interfaces.sumo;

import java.io.IOException;

import junit.framework.Assert;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class SumoTest {

	@Test
	public void runScenarioTest() {
		final SumoTestScenario test = new SumoTestScenario();
		try {
			test.run();
		} catch (IOException e) {
			Assert.fail(e.toString());
		}
		Assert.assertEquals(50, test.flowRoute1_veh.size());
		Assert.assertEquals(50, test.flowRoute2_veh.size());

		Assert.assertEquals(533.0, test.flowRoute1_veh.get(0));
		Assert.assertEquals(140.0, test.flowRoute1_veh.get(49));

		Assert.assertEquals(466.0, test.flowRoute2_veh.get(0));
		Assert.assertEquals(140.0, test.flowRoute2_veh.get(49));
	}
}
