/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Random;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class MultinomialLogitTest2 {

	/*
	 * numerical 1st derivative of choice probability w.r.t. param
	 */
	private static double dProbi_dParamr(final MultinomialLogit mnl,
			final int i, final int r, final double eps) {
		final double param = mnl.getParameter(r);

		mnl.setParameter(r, param + 0.5 * eps);
		final double p2 = mnl.getProbs().get(i);
		mnl.setParameter(r, param - 0.5 * eps);
		final double p1 = mnl.getProbs().get(i);
		mnl.setParameter(r, param);

		return (p2 - p1) / eps;
	}

	/*
	 * numerical second derivative of choice probability w.r.t. parameters
	 */
	private static double d2Probi_dParamr1dParamr2(final MultinomialLogit mnl,
			final int i, final int r1, final int r2, final double eps) {
		final double param2 = mnl.getParameter(r2);

		mnl.setParameter(r2, param2 + 0.5 * eps);
		final double dPi_dParamr1_paramr2Plus = mnl.get_dProb_dParameters(true)
				.getRow(i).get(r1);
		mnl.setParameter(r2, param2 - 0.5 * eps);
		final double dPi_dParamr1_paramr2Minus = mnl
				.get_dProb_dParameters(true).getRow(i).get(r1);
		mnl.setParameter(r2, param2);

		return (dPi_dParamr1_paramr2Plus - dPi_dParamr1_paramr2Minus) / eps;
	}

	@Test
	public void testSensitivities() {
		final Random rnd = new Random(4711);

		for (int runs = 0; runs < 100; runs++) {

			/*
			 * create a random mnl
			 */

			final int choiceSetSize = rnd.nextInt(5) + 1;
			final int attrCnt = rnd.nextInt(5) + 1;

			// System.out.println(choiceSetSize + " ALTERNATIVES WITH " +
			// attrCnt
			// + " ATTRIBUTES");

			final MultinomialLogit mnl = new MultinomialLogit(choiceSetSize,
					attrCnt);
			mnl.setUtilityScale(rnd.nextGaussian());
			for (int j = 0; j < mnl.getAttrCount(); j++) {
				mnl.setCoefficient(j, rnd.nextGaussian());
			}
			for (int i = 0; i < mnl.getChoiceSetSize(); i++) {
				mnl.setASC(i, rnd.nextGaussian());
			}
			for (int i = 0; i < mnl.getChoiceSetSize(); i++) {
				for (int j = 0; j < mnl.getAttrCount(); j++) {
					mnl.setAttribute(i, j, rnd.nextGaussian());
				}
			}

			/*
			 * be sure that everything is covered
			 */
			assertEquals(mnl.getParameterSize(false), mnl.getAttrCount());
			assertEquals(mnl.getParameterSize(true), mnl.getAttrCount()
					+ mnl.getChoiceSetSize());

			/*
			 * test derivatives of probabilities w.r.t. coefficients
			 */

			final Matrix dP_db = mnl.get_dProb_dParameters(true);

			for (int i = 0; i < mnl.getChoiceSetSize(); i++) {
				for (int r = 0; r < mnl.getParameterSize(true); r++) {
					final double analyt = dP_db.getRow(i).get(r);
					final double num = dProbi_dParamr(mnl, i, r, 1e-6);
					// System.out.println("dd analyt = " + analyt + " vs num = "
					// + num + " diff = " + (analyt - num));
					assertEquals(0, num - analyt, 1e-6);
				}
			}

			/*
			 * test 2nd derivatives of probabilities w.r.t. coefficients
			 */

			final List<Matrix> d2P_dbdb = mnl.get_d2P_dbdb(1e-6, true);

			for (int i = 0; i < mnl.getChoiceSetSize(); i++) {
				for (int r1 = 0; r1 < mnl.getParameterSize(true); r1++) {
					for (int r2 = 0; r2 < mnl.getParameterSize(true); r2++) {
						final double analyt = d2P_dbdb.get(i).getRow(r1)
								.get(r2);
						final double num = d2Probi_dParamr1dParamr2(mnl, i, r1,
								r2, 1e-6);
						// System.out.println("dd analyt = " + analyt
						// + " vs num = " + num + " diff = "
						// + (analyt - num));
						assertEquals(0, analyt - num, 1e-5);
					}
				}
			}
		}
	}
}
