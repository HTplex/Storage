/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;

import java.util.Random;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class CholeskyTest {

	// RANDOM TESTING

	private Matrix newLowerTriangular(final Random rnd) {
		final int dim = rnd.nextInt(5) + 1;
		final Matrix result = new Matrix(dim, dim);
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < i; j++) {
				result.getRow(i).set(j, rnd.nextGaussian());
			}
			result.getRow(i).set(i, 1e-9 + rnd.nextDouble());
		}
		return result;
	}

	@Test
	public void testRootRandom() {
		final Random rnd = new Random(42);

		for (int run = 0; run < 10; run++) {

			final Matrix _L = newLowerTriangular(rnd);
			final Matrix _A = Matrix.product(_L, _L.newTransposed());
			final Cholesky c = new Cholesky();
			c.calculateSquareRoot(_A);

			assertNotNull(c.getResult());
			assertEquals(_L.rowSize(), c.getResult().rowSize());
			assertEquals(_L.columnSize(), c.getResult().columnSize());
			for (int i = 0; i < _L.rowSize(); i++) {
				for (int j = 0; j < _L.columnSize(); j++) {
					assertEquals(_L.getRow(i).get(j), c.getResult().getRow(i)
							.get(j), 1e-9);
				}
			}
		}
	}

	@Test
	public void testInvertLowerTriangularRandom() {
		final Random rnd = new Random(1976);

		for (int run = 0; run < 10; run++) {

			final Matrix _L = newLowerTriangular(rnd);
			final Cholesky c = new Cholesky();

			final Matrix _L_inv = c.invertLowerTriangular(_L);
			assertNotNull(_L_inv);
			assertEquals(_L.rowSize(), _L_inv.rowSize());
			assertEquals(_L.columnSize(), _L_inv.columnSize());

			final Matrix prod = Matrix.product(_L, _L_inv);
			for (int i = 0; i < _L.rowSize(); i++) {
				for (int j = 0; j < _L.columnSize(); j++) {
					assertEquals(i == j ? 1.0 : 0.0, prod.getRow(i).get(j),
							1e-9);
				}
			}
		}
	}

	@Test
	public void testInvertRandom() {
		final Random rnd = new Random(4711);

		for (int run = 0; run < 10; run++) {

			final Matrix _L = newLowerTriangular(rnd);
			final Matrix _A = Matrix.product(_L, _L.newTransposed());
			final Cholesky c = new Cholesky();
			c.invert(_A);
			final Matrix _A_inv = c.getResult();

			assertNotNull(_A_inv);
			assertEquals(_A.rowSize(), _A_inv.rowSize());
			assertEquals(_A.columnSize(), _A_inv.columnSize());

			final Matrix prod = Matrix.product(_A, _A_inv);
			for (int i = 0; i < _A.rowSize(); i++) {
				for (int j = 0; j < _A.columnSize(); j++) {
					assertEquals(i == j ? 1.0 : 0.0, prod.getRow(i).get(j),
							1e-9);
				}
			}
		}
	}


	// NON-RANDOM TESTING

	@Test
	public void testRoot() {
		final Cholesky c = new Cholesky();
		final Matrix _A = new Matrix(2, 2);
		_A.getRow(0).set(0, 1);
		_A.getRow(0).set(1, 2);
		_A.getRow(1).set(0, 2);
		_A.getRow(1).set(1, 5);
		c.calculateSquareRoot(_A);
		final Matrix _L = c.getResult().copy();
		assertEquals(1, _L.getRow(0).get(0));
		assertEquals(0, _L.getRow(0).get(1));
		assertEquals(2, _L.getRow(1).get(0));
		assertEquals(1, _L.getRow(1).get(1));
	}

	public void testInvert() {
		final Cholesky c = new Cholesky();
		final Matrix _A = new Matrix(2, 2);
		_A.getRow(0).set(0, 1);
		_A.getRow(0).set(1, 2);
		_A.getRow(1).set(0, 2);
		_A.getRow(1).set(1, 5);
		c.invert(_A);
		final Matrix _A_inv = c.getResult();
		assertEquals(-4, _A_inv.getRow(0).get(0));
		assertEquals(+3, _A_inv.getRow(0).get(1));
		assertEquals(+3, _A_inv.getRow(1).get(0));
		assertEquals(-2, _A_inv.getRow(1).get(1));
	}
	
}
