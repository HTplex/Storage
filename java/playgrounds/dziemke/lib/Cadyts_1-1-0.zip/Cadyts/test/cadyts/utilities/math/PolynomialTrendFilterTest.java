/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import static org.junit.Assert.*;

import org.junit.Test;

import cadyts.utilities.math.PolynomialTrendFilter;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class PolynomialTrendFilterTest {

	@Test
	public void testPredictDeterministic() {
		final PolynomialTrendFilter ptf = new PolynomialTrendFilter(1.0, 1);
		ptf.setLambda(1);
		ptf.add(1);
		ptf.add(2);
		ptf.add(3);
		ptf.add(4);
		assertEquals(3, ptf.predict(-1), 1e-4);
		assertEquals(4, ptf.predict(0), 1e-4);
		assertEquals(5, ptf.predict(+1), 1e-4);
		assertEquals(-6, ptf.predict(-10), 1e-4);
	}

	@Test
	public void testPredictStochastic() {
		final PolynomialTrendFilter ptf = new PolynomialTrendFilter(1.0, 1);
		ptf.setLambda(1);
		ptf.add(1 + .1);
		ptf.add(2 - .1);
		ptf.add(3 + .1);
		ptf.add(4 - .1);
		assertEquals(3, ptf.predict(-1), 1e-1);
		assertEquals(4, ptf.predict(0), 1e-1);
		assertEquals(5, ptf.predict(+1), 1e-1);
	}
}
