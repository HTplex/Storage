/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.demand;

import junit.framework.Assert;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class PlanChoiceDistributionTest {

	@Test
	public void testIncrementalBuilding() {
		final PlanChoiceDistribution<Plan<String>> pcd = new PlanChoiceDistribution<Plan<String>>();
		Assert.assertNull(pcd.getChoiceProbabilities(null));

		final double value0 = 0.1;
		pcd.addChoiceProbability(value0);
		Assert.assertEquals(1, pcd.getChoiceProbabilities(null).size());
		Assert.assertEquals(value0, pcd.getChoiceProbabilities(null).get(0));

		final double value1 = 0.2;
		pcd.addChoiceProbability(value1);
		Assert.assertEquals(2, pcd.getChoiceProbabilities(null).size());
		Assert.assertEquals(value0, pcd.getChoiceProbabilities(null).get(0));
		Assert.assertEquals(value1, pcd.getChoiceProbabilities(null).get(1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testProbBoundaryCheck1() {
		final PlanChoiceDistribution<Plan<String>> pcd = new PlanChoiceDistribution<Plan<String>>();
		pcd.addChoiceProbability(-0.1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testProbBoundaryCheck2() {
		final PlanChoiceDistribution<Plan<String>> pcd = new PlanChoiceDistribution<Plan<String>>();
		pcd.addChoiceProbability(Double.NEGATIVE_INFINITY);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testProbBoundaryCheck3() {
		final PlanChoiceDistribution<Plan<String>> pcd = new PlanChoiceDistribution<Plan<String>>();
		pcd.addChoiceProbability(Double.POSITIVE_INFINITY);
	}
}
