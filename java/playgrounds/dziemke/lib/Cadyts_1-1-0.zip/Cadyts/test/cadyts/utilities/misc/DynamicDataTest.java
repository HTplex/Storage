/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class DynamicDataTest {

	@Test
	public void testDynamicData1() {
		new DynamicData<Object>(-10, 1, 1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testDynamicData2() {
		new DynamicData<Object>(-10, 0, 1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testDynamicData3() {
		new DynamicData<Object>(-10, 1, 0);
	}

	@Test
	public void testGetSum() {
		DynamicData<String> dd = new DynamicData<String>(0, 3600, 3);
		dd.put("x", 0, 0);
		dd.put("x", 1, 1);
		dd.put("x", 2, 2);
		assertEquals(1.0, dd.getSum("x", 3600, 2 * 3600));
		assertEquals(.5, dd.getSum("x", 3600 - 1800, 3600 + 1800));
		assertEquals(1.5, dd.getSum("x", 3600 + 1800, 2 * 3600 + 1800));
		assertEquals(2.0, dd.getSum("x", 3600 - 1800, 2 * 3600 + 1800));
	}

	@Test
	public void testGetAverage() {
		DynamicData<String> dd = new DynamicData<String>(0, 3600, 3);
		dd.put("x", 0, 0.0);
		dd.put("x", 1, 1.0);
		dd.put("x", 2, 2.0);
		assertEquals(1.0, dd.getAverage("x", 3600, 2 * 3600));
		assertEquals(0.5, dd.getAverage("x", 3600 - 1800, 3600 + 1800));
		assertEquals(1.5, dd.getSum("x", 3600 + 1800, 2 * 3600 + 1800));
		assertEquals(1.0, dd.getAverage("x", 3600 - 1800, 2 * 3600 + 1800));
	}

	@Test
	public void overrideTest() {
		DynamicData<String> dest = new DynamicData<String>(0, 3600, 3);
		dest.add("B", 0, -1.0);
		dest.add("B", 1, -10.0);
		dest.add("B", 2, -100.0);
		dest.add("C", 1, 47.11);
		DynamicData<String> source = new DynamicData<String>(0, 3600, 3);
		source.add("A", 0, 1.0);
		source.add("B", 1, 0.0);

		dest.overrideWithNonZeros(source);

		assertEquals(3, dest.data.keySet().size());
		assertTrue(dest.data.containsKey("A"));
		assertTrue(dest.data.containsKey("B"));
		assertTrue(dest.data.containsKey("C"));

		assertEquals(1.0, dest.data.get("A")[0]);
		assertEquals(0.0, dest.data.get("A")[1]);
		assertEquals(0.0, dest.data.get("A")[2]);

		assertEquals(-1.0, dest.data.get("B")[0]);
		assertEquals(-10.0, dest.data.get("B")[1]);
		assertEquals(-100.0, dest.data.get("B")[2]);

		assertEquals(0.0, dest.data.get("C")[0]);
		assertEquals(47.11, dest.data.get("C")[1]);
		assertEquals(0.0, dest.data.get("C")[2]);
	}
}
