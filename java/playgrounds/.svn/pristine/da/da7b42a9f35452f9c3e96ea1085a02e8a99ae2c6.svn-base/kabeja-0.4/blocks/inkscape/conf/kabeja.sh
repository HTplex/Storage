#!/bin/sh
KABEJA_HOME=`dirname $0`
java -jar  $KABEJA_HOME/kabeja-dxf2svg.jar "$1"

