/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.calibrators.filebased.xml;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import org.junit.Assert;
import org.junit.Test;

import cadyts.calibrators.filebased.Agent;
import cadyts.demand.Plan;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class TestXMLPopulationFileReaderAndHandler {

	static final String POPULATION = "population";

	static final String AGENT = "agent";

	static final String ID = "id";

	private File generatePopulationFile(final int entries) throws IOException {
		final File result = new File("test892368238963486.tmp");
		final PrintWriter writer = new PrintWriter(result);
		writer.println("<" + POPULATION + ">");
		for (int i = 0; i < entries; i++) {
			writer.println("  <" + AGENT + " " + ID + "=\"" + i + "\">");
			writer.println("  </" + AGENT + ">");
		}
		writer.println("</" + POPULATION + ">");
		writer.flush();
		writer.close();
		return result;
	}

	// TESTING THE BASE CLASSES

	private void testDoNothing(final int popSize) throws IOException {
		final File testFile = generatePopulationFile(popSize);
		final XMLPopulationFileReader<Agent<Plan<String>, ?>> reader = new XMLPopulationFileReader<Agent<Plan<String>, ?>>();
		final TestPopulationHandlerSubclass handler = new TestPopulationHandlerSubclass();
		reader.setPopulationHandler(handler);
		final Iterable<Agent<Plan<String>, ?>> agentSource = reader
				.getPopulationSource(testFile.getName());
		for (@SuppressWarnings("unused")
		Agent<?, ?> agent : agentSource) {
		}
		Assert.assertNotNull(agentSource);
		testFile.delete();
	}

	@Test
	public void testDoNothing0Agent() throws IOException {
		this.testDoNothing(0);
	}

	@Test
	public void testDoNothing1Agent() throws IOException {
		this.testDoNothing(1);
	}

	@Test
	public void testDoNothing2Agent() throws IOException {
		this.testDoNothing(2);
	}

	// TESTING THE BASE CLASSES WITH A LITTLE BIT OF IMPLEMENTATION

	private void testParsingHandling(final int popSize) throws IOException {
		final File testFile = generatePopulationFile(popSize);
		final XMLPopulationFileReader<Agent<Plan<String>, ?>> reader = new XMLPopulationFileReader<Agent<Plan<String>, ?>>();
		final TestPopulationHandlerSubclass handler = new TestPopulationHandlerSubclass();
		reader.setPopulationHandler(handler);
		final Iterable<Agent<Plan<String>, ?>> agentSource = reader
				.getPopulationSource(testFile.getName());
		Assert.assertNotNull(agentSource);

		int encounteredAgents = 0;
		for (Agent<Plan<String>, ?> agent : agentSource) {
			Assert.assertEquals(agent.getId(), Integer
					.toString(encounteredAgents));
			encounteredAgents++;
		}
		Assert.assertEquals(encounteredAgents, popSize);
		testFile.delete();
	}

	@Test
	public void testParsingHandling0Agents() throws IOException {
		this.testParsingHandling(0);
	}

	@Test
	public void testParsingHandling1Agents() throws IOException {
		this.testParsingHandling(1);
	}

	@Test
	public void testParsingHandling2Agents() throws IOException {
		this.testParsingHandling(2);
	}
}
