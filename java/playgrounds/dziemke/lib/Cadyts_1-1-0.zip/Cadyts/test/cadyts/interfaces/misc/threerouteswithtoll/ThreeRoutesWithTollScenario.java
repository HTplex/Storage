/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */
package cadyts.interfaces.misc.threerouteswithtoll;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import cadyts.calibrators.analytical.ChoiceParameterCalibrator;
import cadyts.demand.Plan;
import cadyts.demand.PlanBuilder;
import cadyts.measurements.SingleLinkMeasurement;
import cadyts.measurements.SingleLinkMeasurement.TYPE;
import cadyts.supply.SimResults;
import cadyts.utilities.math.BasicStatistics;
import cadyts.utilities.math.Matrix;
import cadyts.utilities.math.MultinomialLogit;
import cadyts.utilities.math.Vector;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
class ThreeRoutesWithTollScenario {

	/*-
	 *             
	 *    LINK_0     LINK_1
	 * o---------->o--------o-----> 
	 *             |        |
	 *             o--------o  <- LINK_2, only this one has a toll
	 *             |        |
	 *             o--------o  <- LINK_3
	 *
	 *
	 * This is a static experiment; all dynamics are aggregated into a single 
	 * time bin of 86400 seconds length.
	 */

	// -------------------- FIXED LINK DEFINITIONS --------------------
	// 
	final String link0 = "0";

	final String link1 = "1";

	final String link2 = "2";

	final String link3 = "3";

	final double minTT1 = 0;

	final double minTT2 = 1;

	final double minTT3 = 2;

	final double capFact = 0.75;

	final double bprExp = 2;

	final double toll = 1;

	final double valueOfTime = 1;

	// -------------------- FIXED SIMULATION CONTROL --------------------

	final int START_S = 0;

	final int END_S = 86400;

	final int popSize = 1000;

	final int maxIts = 500;

	final double noiseScale = 0.0;

	final boolean useChoiceHessian = true;

	// -------------------- MEMBERS --------------------

	Vector result = null;

	Matrix covariance = null;

	// --------------- INNER SIM RESULT CONTAINER CLASS ---------------

	class SimResultFromFlowArray implements SimResults<String> {

		private static final long serialVersionUID = 1L;

		private final double[] flows;

		private SimResultFromFlowArray(final double[] flows) {
			this.flows = flows;
		}

		@Override
		public double getSimValue(String link, int startTime_s, int endTime_s,
				TYPE type) {

			if (!SingleLinkMeasurement.TYPE.FLOW_VEH_H.equals(type)) {
				throw new RuntimeException(
						"this test only functions with measurement of type "
								+ SingleLinkMeasurement.TYPE.FLOW_VEH_H);
			}

			if (link1.equals(link)) {
				return this.flows[0];
			} else if (link2.equals(link)) {
				return this.flows[1];
			} else if (link3.equals(link)) {
				return this.flows[2];
			} else {
				throw new RuntimeException("called getSimValue for link: "
						+ link);
			}
		}
	}

	// -------------------- RUNNING DIFFERENT SCENARIOS --------------------

	private MultinomialLogit choiceModel;

	private void initChoiceModel(final double ttCoeff, final double tollCoeff) {
		this.choiceModel = new MultinomialLogit(3, 2);
		this.choiceModel.setUtilityScale(1.0 / valueOfTime);
		this.choiceModel.setASC(0, 0.0);
		this.choiceModel.setASC(1, 0.0);
		this.choiceModel.setASC(2, 0.0);
		this.choiceModel.setCoefficient(0, ttCoeff); // travel time
		this.choiceModel.setCoefficient(1, tollCoeff); // toll
	}

	public void runDataGenerationWithoutToll() {
		final double ttCoeff = -valueOfTime;
		final double tollCoeff = 0;
		initChoiceModel(ttCoeff, tollCoeff);
		final boolean estimate = false;
		this.run(estimate);
	}

	public void runDataGenerationWithToll() {
		final double ttCoeff = -valueOfTime;
		final double tollCoeff = -1.0;
		initChoiceModel(ttCoeff, tollCoeff);
		final boolean estimate = false;
		this.run(estimate);
	}

	public void runEstimation() {
		final double ttCoeff = 0.0;
		final double tollCoeff = 0.0;
		initChoiceModel(ttCoeff, tollCoeff);
		final boolean estimate = true;
		this.run(estimate);
	}

	// -------------------- THE MAIN LOOP --------------------

	private List<Plan<String>> tt2demand(double[] tt,
			final ChoiceParameterCalibrator<String> ac) {

		final List<Plan<String>> plans = new ArrayList<Plan<String>>(2);
		final PlanBuilder<String> pB = new PlanBuilder<String>();
		final int time_s = (END_S - START_S) / 2;
		// build plan 1 (for route 1)
		pB.reset();
		pB.addEntry(link0, time_s);
		pB.addTurn(link1, time_s);
		plans.add(pB.getResult());
		// build plan 2 (for route 2)
		pB.reset();
		pB.addEntry(link0, time_s);
		pB.addTurn(link2, time_s);
		plans.add(pB.getResult());
		// build plan3 (for route 3)
		pB.reset();
		pB.addEntry(link0, time_s);
		pB.addTurn(link3, time_s);
		plans.add(pB.getResult());

		final Random r = ac.getRandom();
		final List<Plan<String>> result = new ArrayList<Plan<String>>(popSize);
		for (int n = 0; n < popSize; n++) {
			// attributes of alternative 0 == route 1 (no toll)
			choiceModel.setAttribute(0, 0, tt[0]
					* (1.0 + noiseScale * r.nextGaussian()));
			choiceModel.setAttribute(0, 1, 0.0);
			// attributes of alternative 1 == route 2 (with toll)
			choiceModel.setAttribute(1, 0, tt[1]
					* (1.0 + noiseScale * r.nextGaussian()));
			choiceModel.setAttribute(1, 1, toll);
			// attributes of alternative 2 == route 3 (no toll)
			choiceModel.setAttribute(2, 0, tt[2]
					* (1.0 + noiseScale * r.nextGaussian()));
			choiceModel.setAttribute(2, 1, 0.0);
			// generate choice
			ac.selectPlan(null, plans, choiceModel.getProbs(), choiceModel
					.get_dProb_dParameters(false),
					this.useChoiceHessian ? choiceModel.get_d2P_dbdb(1e-6,
							false) : null);
			result.add(plans.get(ac.getLastChoiceIndex()));
		}
		return result;
	}

	private double[] demand2flows(final List<Plan<String>> demand) {
		final double[] result = new double[3];
		for (Plan<String> plan : demand) {
			final String link = plan.getStep(0).getLink();
			if (link1.equals(link)) {
				result[0]++;
			} else if (link2.equals(link)) {
				result[1]++;
			} else if (link3.equals(link)) {
				result[2]++;
			} else {
				System.err.println("WRONG DEMAND");
				System.exit(-1);
			}
		}
		if (result[0] + result[1] + result[2] != popSize) {
			System.err.println("WRONG DEMAND");
			System.exit(-1);
		}
		return result;
	}

	private double[] flows2tt(final double[] flows) {
		final double[] result = new double[3];
		result[0] = minTT1 + Math.pow(flows[0] / (capFact * popSize), bprExp);
		result[1] = minTT2 + Math.pow(flows[1] / (capFact * popSize), bprExp);
		result[2] = minTT3 + Math.pow(flows[2] / (capFact * popSize), bprExp);
		return result;
	}

	void run(final boolean estimate) {

		/*
		 * Initialize the calibration.
		 */

		final Vector initialParams = new Vector(2);

		initialParams.set(0, 0); // tt coeff
		initialParams.set(1, 0); // toll coeff
		// initialParams.set(2, 0.0); // asc route 1
		// initialParams.set(3, 0.0); // asc route 2
		// initialParams.set(4, 0.0); // asc route 3

		final Vector initialParamVars = new Vector(2);
		final double stddev = 1000;
		final double var = stddev * stddev;
		initialParamVars.set(0, var);
		initialParamVars.set(1, var);
		// initialParamVars.set(2, var);
		// initialParamVars.set(3, var);
		// initialParamVars.set(4, var);

		final ChoiceParameterCalibrator<String> calibrator = new ChoiceParameterCalibrator<String>(
				"calibration-log.txt", 42L, END_S, 2);
		calibrator.setStatisticsFile("calibration-stats.txt");

		// calibrator.setPreparatoryIterations(5);

		calibrator.setInitialStepSize(1.0);
		calibrator.setMsaExponent(0.5);
		calibrator.setUseApproximateNetwton(true);

		calibrator.setInitialParameters(initialParams);
		calibrator.setInitialParameterVariances(initialParamVars);

		calibrator.setRegressionInertia(0.95);
		calibrator.setProportionalAssignment(true);
		calibrator.setFreezeIteration(this.maxIts / 3);
		calibrator.setMinStddev(1, SingleLinkMeasurement.TYPE.FLOW_VEH_H);
		calibrator.setVarianceScale(1.0);

		/*
		 * Specify the measurement.
		 */

		if (estimate) {
			// meas. with toll
			final double y1 = 649;
			final double y2 = 176;
			final double y3 = 176;
			// meas. without toll
			// final double y1 = 563;
			// final double y2 = 307;
			// final double y3 = 130;
			calibrator.addMeasurement(link1, START_S, END_S, y1,
					SingleLinkMeasurement.TYPE.FLOW_VEH_H);
			calibrator.addMeasurement(link2, START_S, END_S, y2,
					SingleLinkMeasurement.TYPE.FLOW_VEH_H);
			calibrator.addMeasurement(link3, START_S, END_S, y3,
					SingleLinkMeasurement.TYPE.FLOW_VEH_H);
		}

		/*
		 * Start the calibration loop.
		 */

		final StringBuffer dataLog = new StringBuffer();

		final BasicStatistics[] flowStats = new BasicStatistics[3];
		flowStats[0] = new BasicStatistics();
		flowStats[1] = new BasicStatistics();
		flowStats[2] = new BasicStatistics();

		final BasicStatistics[] ttStats = new BasicStatistics[3];
		ttStats[0] = new BasicStatistics();
		ttStats[1] = new BasicStatistics();
		ttStats[2] = new BasicStatistics();

		double[] tt = new double[] { minTT1, minTT2, minTT3 };
		List<Plan<String>> demand;
		double[] flows = null;

		for (int it = 0; it < maxIts; it++) {

			demand = this.tt2demand(tt, calibrator);
			flows = this.demand2flows(demand);
			tt = this.flows2tt(flows);

			flowStats[0].add(flows[0]);
			flowStats[1].add(flows[1]);
			flowStats[2].add(flows[2]);

			ttStats[0].add(tt[0]);
			ttStats[1].add(tt[1]);
			ttStats[2].add(tt[2]);

			dataLog.append(flows[0] + "\t" + flows[1] + "\t" + flows[2] + "\t"
					+ choiceModel.getParameters(false).get(0) + "\t"
					+ choiceModel.getParameters(false).get(1) + "\n");

			calibrator.afterNetworkLoading(new SimResultFromFlowArray(flows));

			if (estimate) {
				choiceModel.setParameters(calibrator.getParameters());
			}

			System.err.println(calibrator.getParameterCovariance());

		}
		System.out.println(dataLog.toString());
		System.out.println();

		System.out.println(calibrator.getParameters());
		System.out.println();

		System.out.println(calibrator.getParameterCovariance());
		System.out.println();

		if (!estimate) {
			System.out.println("avg flows " + flowStats[0].getAvg() + " "
					+ flowStats[1].getAvg() + " " + flowStats[2].getAvg());
			System.out.println("avg times " + ttStats[0].getAvg() + " "
					+ ttStats[1].getAvg() + " " + ttStats[2].getAvg());
		}

		if (estimate) {
			this.result = calibrator.getParameters();
			this.covariance = calibrator.getParameterCovariance();
		}
	}

	// ----------------------------------------------------------------

	// public static void main(String[] args) {
	// // (new ThreeRoutesWithTollScenario()).runDataGenerationWithoutToll();
	// // (new ThreeRoutesWithTollScenario()).runDataGenerationWithToll();
	// (new ThreeRoutesWithTollScenario()).runEstimation();
	// System.out.println("DONE.");
	// }
}
