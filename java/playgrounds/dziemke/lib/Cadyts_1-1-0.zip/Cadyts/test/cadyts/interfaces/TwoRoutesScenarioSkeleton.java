/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.interfaces;

import java.util.ArrayList;
import java.util.List;

import cadyts.demand.Plan;
import cadyts.demand.PlanBuilder;
import cadyts.measurements.SingleLinkMeasurement;
import cadyts.supply.BasicSimResults;
import cadyts.supply.SimResults;
import cadyts.utilities.misc.DynamicData;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class TwoRoutesScenarioSkeleton {

	/*-
	 * 
	 *               LINK_1  
	 *             ----------
	 *    LINK_0   |        |
	 * o---------->o        o-----> 
	 *             |        |
	 *             ----------
	 *               LINK_2
	 *
	 *
	 * This is a very simple skeleton of a static two-link scenario.
	 * 
	 * Since the calibration is dynamic, only traffic totals within 
	 * an entire day are considered.
	 * 
	 */

	// -------------------- CONSTANTS --------------------
	//
	protected static final String LINK_0 = "0";

	protected static final String LINK_1 = "1";

	protected static final String LINK_2 = "2";

	protected static final int START_S = 0;

	protected static final int END_S = 24 * 3600;

	// -------------------- SCENARIO CONFIGURATION --------------------

	public int popSize = 1000;

	public double y1_veh = 0;

	public double stddev1_veh = 15;

	public int maxIts = 100;

	public double mu = 1;

	public double minTT = 0;

	public double capFact = 0.75;

	public double bprExp = 2;

	public int ttAverageWindow = 5;

	// -------------------- SIMULATION --------------------

	protected List<Plan<String>> choiceSet() {
		final List<Plan<String>> result = new ArrayList<Plan<String>>(2);
		final PlanBuilder<String> factory = new PlanBuilder<String>();

		factory.addEntry(LINK_0, 0);
		factory.addTurn(LINK_1, 1);
		factory.addExit(2);
		result.add(factory.getResult());
		factory.reset();

		factory.addEntry(LINK_0, 0);
		factory.addTurn(LINK_2, 1);
		factory.addExit(2);
		result.add(factory.getResult());
		factory.reset();
		
		return result;
	}

	
	protected List<Double> routeFlows(final List<Plan<String>> plans) {
		double q1 = 0;
		double q2 = 0;
		for (Plan<String> plan : plans) {
			if (LINK_1.equals(plan.getStep(0).getLink())) {
				q1++;
			} else if (LINK_2.equals(plan.getStep(0).getLink())) {
				q2++;
			} else {
				System.err.println("WRONG DEMAND");
				System.exit(-1);
			}
		}
		if (q1 + q2 != this.popSize) {
			System.err.println("WRONG DEMAND");
			System.exit(-1);
		}
		final List<Double> result = new ArrayList<Double>();
		result.add(q1);
		result.add(q2);
		return result;
	}

	protected SimResults<String> simResults(List<Double> routeFlows) {
		BasicSimResults<String> result = new BasicSimResults<String>(START_S,
				(END_S - START_S), 1);
		final DynamicData<String> counts = result
				.getSimResults(SingleLinkMeasurement.TYPE.COUNT_VEH);
		counts.put(LINK_0, 0, routeFlows.get(0) + routeFlows.get(1));
		counts.put(LINK_1, 0, routeFlows.get(0));
		counts.put(LINK_2, 0, routeFlows.get(1));
		return result;
	}

	protected List<Double> travelTimes(final List<Double> routeFlows) {
		final List<Double> travelTimes = new ArrayList<Double>(2);
		travelTimes.add(this.minTT
				+ Math.pow(routeFlows.get(0) / (this.capFact * this.popSize),
						this.bprExp));
		travelTimes.add(this.minTT
				+ Math.pow(routeFlows.get(1) / (this.capFact * this.popSize),
						this.bprExp));
		return travelTimes;
	}

	protected List<Double> routeProbs(final List<Double> travelTimes) {
		final double exp1 = Math.exp(-this.mu * travelTimes.get(0));
		final double exp2 = Math.exp(-this.mu * travelTimes.get(1));
		final double p1 = exp1 / (exp1 + exp2);
		final List<Double> result = new ArrayList<Double>(2);
		result.add(p1);
		result.add(1.0 - p1);
		return result;
	}

	protected List<Double> averageTravelTimes(
			final List<List<Double>> travelTimes) {
		final int window = Math.min(this.ttAverageWindow, travelTimes.size());
		double tt1 = 0;
		double tt2 = 0;
		for (int i = (travelTimes.size() - window); i < travelTimes.size(); i++) {
			tt1 += travelTimes.get(i).get(0);
			tt2 += travelTimes.get(i).get(1);
		}
		final List<Double> result = new ArrayList<Double>(2);
		result.add(tt1 / window);
		result.add(tt2 / window);
		return result;
	}
}
