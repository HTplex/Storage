/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.demand;

import static org.junit.Assert.*;

import org.junit.Test;

import cadyts.demand.PlanStep;

/**
 * 
 * @author Gunnar Fl�tter�d
 *
 */
public class PlanStepTest {

	@Test(expected = IllegalArgumentException.class)
	public void testPlanStep1() {
		new PlanStep<Integer>(null, 100);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testPlanStep2() {
		new PlanStep<String>("link", -1);
	}

	@Test
	public void testPlanStep3() {
		new PlanStep<String>("", 0);
		new PlanStep<String>("link", Integer.MAX_VALUE);
	}

	@Test
	public void testGetLink() {
		final PlanStep<String> ps = new PlanStep<String>("", 10);
		assertNotNull(ps.getLink());
	}

	@Test
	public void testGetEntryTime_s() {
		PlanStep<String> ps = new PlanStep<String>("", 0);
		assertEquals(0, ps.getEntryTime_s());
		ps = new PlanStep<String>("", Integer.MAX_VALUE);
		assertEquals(Integer.MAX_VALUE, ps.getEntryTime_s());
	}
}
