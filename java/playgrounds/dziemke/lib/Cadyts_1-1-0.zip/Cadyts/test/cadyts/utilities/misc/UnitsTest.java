/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import static cadyts.utilities.misc.Units.D_PER_H;
import static cadyts.utilities.misc.Units.D_PER_S;
import static cadyts.utilities.misc.Units.H_PER_D;
import static cadyts.utilities.misc.Units.H_PER_S;
import static cadyts.utilities.misc.Units.KM_H_PER_M_S;
import static cadyts.utilities.misc.Units.KM_PER_M;
import static cadyts.utilities.misc.Units.M_PER_KM;
import static cadyts.utilities.misc.Units.M_S_PER_KM_H;
import static cadyts.utilities.misc.Units.S_PER_D;
import static cadyts.utilities.misc.Units.S_PER_H;
import static cadyts.utilities.misc.Units.VEH_H_PER_VEH_S;
import static cadyts.utilities.misc.Units.VEH_KM_PER_VEH_M;
import static cadyts.utilities.misc.Units.VEH_M_PER_VEH_KM;
import static cadyts.utilities.misc.Units.VEH_S_PER_VEH_H;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class UnitsTest {

	@Test
	public void checkVales() {

		final int sec_per_day = 24 * 60 * 60;

		assertEquals(3600, S_PER_H);
		assertEquals(1.0 / 3600.0, H_PER_S);
		assertEquals(24, H_PER_D);
		assertEquals(1.0 / 24.0, D_PER_H);
		assertEquals(sec_per_day, S_PER_D);
		assertEquals(1.0 / sec_per_day, D_PER_S);

		assertEquals(1000, M_PER_KM);
		assertEquals(0.001, KM_PER_M);

		assertEquals(3600, VEH_H_PER_VEH_S);
		assertEquals(1.0 / 3600, VEH_S_PER_VEH_H);

		assertEquals(1000, VEH_KM_PER_VEH_M);
		assertEquals(0.001, VEH_M_PER_VEH_KM);

		assertEquals(1.0 / 3.6, M_S_PER_KM_H);
		assertEquals(3.6, KM_H_PER_M_S);
	}
}
