/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.demand;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.Iterator;

import org.junit.Test;

import cadyts.demand.BasicPlan;
import cadyts.demand.PlanStep;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class PlanTest {

	@Test
	public void testPlan() {
		new BasicPlan<String>();
	}

	@Test
	public void testAddStep() {
		for (int i = 0; i < 10; i++) {
			final BasicPlan<Integer> p = new BasicPlan<Integer>();
			for (int j = 0; j < i; j++) {
				p.addStep(new PlanStep<Integer>(j, j));
			}
			p.trim();
		}
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddNullStep() {
		(new BasicPlan<String>()).addStep(null);
	}

	@Test
	public void testTrim() {
		(new BasicPlan<String>()).trim();
	}

	@Test
	public void testSize() {
		final BasicPlan<Integer> p = new BasicPlan<Integer>();
		for (int i = 0; i < 10; i++) {
			assertEquals(i, p.size());
			p.addStep(new PlanStep<Integer>(i, i));
		}
	}

	@Test
	public void testIterator() {
		final BasicPlan<Integer> p = new BasicPlan<Integer>();
		for (int i = 0; i < 10; i++) {
			final Iterator<PlanStep<Integer>> it = p.iterator();
			for (int j = 0; j < i; j++) {
				it.next();
			}
			assertFalse(it.hasNext());
			p.addStep(new PlanStep<Integer>(i, i));
		}
	}
}
