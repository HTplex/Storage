/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import org.junit.Test;

import cadyts.utilities.misc.TimedElement;

/**
 * 
 * @author Gunnar Fl�tter�d
 *
 */
public class TimedElementTest {

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction1() {
		new TimedElement(-1, 10000);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction2() {
		new TimedElement(10000, 1000 * 1000);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction3() {
		new TimedElement(3600, 3600);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction4() {
		new TimedElement(7200, 3600);
	}

	@Test
	public void testConstruction5() {
		new TimedElement(0, 24 * 60 * 60);
		new TimedElement(0, 1);
		new TimedElement(24 * 60 * 60 - 1, 24 * 60 * 60);
	}
}
