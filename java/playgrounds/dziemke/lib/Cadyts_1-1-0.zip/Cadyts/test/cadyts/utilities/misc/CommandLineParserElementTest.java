/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import org.junit.Assert;
import org.junit.Test;

import cadyts.utilities.misc.CommandLineParserElement;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class CommandLineParserElementTest {

	@Test(expected = IllegalArgumentException.class)
	public void testCommandLineParserElement() {
		new CommandLineParserElement(null, false, "default", "explanation");
	}

	@Test
	public void testEquals() {
		final CommandLineParserElement e1 = new CommandLineParserElement(
				"key1", false, "defaultValue", "explanation");
		final CommandLineParserElement e2 = new CommandLineParserElement(
				"key1", true, "defaultValue", "explanation");
		final CommandLineParserElement e3 = new CommandLineParserElement(
				"key1", false, "xyz", "explanation");
		final CommandLineParserElement e4 = new CommandLineParserElement(
				"key1", false, "defaultValue", "XYZ");
		Assert.assertEquals(e1, e2);
		Assert.assertEquals(e1, e3);
		Assert.assertEquals(e1, e4);

		final CommandLineParserElement o1 = new CommandLineParserElement(
				"OTHER", false, "defaultValue", "explanation");
		Assert.assertFalse(e1.equals(o1));
		Assert.assertFalse(e1.equals(null));
		Assert.assertFalse(e1.equals("smth totally different"));
	}
}
