/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */
package cadyts.utilities.math;

import static org.junit.Assert.assertEquals;

import java.util.Random;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class RegressionTest {

	@Test(expected = IllegalArgumentException.class)
	public void testRegressionConstruction1() {
		new Regression(1.0, new Vector(2), new Matrix(1, 2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRegressionConstruction2() {
		new Regression(1.0, new Vector(2), new Matrix(2, 1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRegressionConstruction3() {
		new Regression(1.0, null, new Matrix(1, 2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRegressionConstruction4() {
		new Regression(1.0, new Vector(2), null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRegressionInt() {
		new Regression(-1, 1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRegressionInt2() {
		new Regression(0, 1);
	}

	@Test()
	public void testRegressionInt3() {
		new Regression(1, 1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRegressionDoubleInt() {
		new Regression(-.1, 1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRegressionDoubleInt2() {
		new Regression(0, 1);
	}

	@Test()
	public void testRegressionDoubleInt3() {
		new Regression(1, 1);
	}

	@Test()
	public void testRegressionDeterministic() {
		final Regression r = new Regression(1.0, 1);
		for (double x = 0; x < 100; x++) {
			r.update(new Vector(x), 2.0 * x + 1.0);
		}
		assertEquals(1, r.getCoefficients().size());
		assertEquals(2.0, r.getCoefficients().get(0));
	}

	@Test()
	public void testRegressionStochastic() {
		final Regression r = new Regression(1.0, 1);
		for (double x = 0; x < 100; x++) {
			final double noise;
			if (x % 2 == 0) {
				noise = -1;
			} else {
				noise = +1;
			}
			r.update(new Vector(x), 2.0 * x + 1.0 + noise);
		}
		assertEquals(1, r.getCoefficients().size());
		assertEquals(2.0, r.getCoefficients().get(0));
	}

	@Test
	public void testAppendParameters() {
		final Random rnd = new Random();
		final Regression r = new Regression(1.0, 2);
		for (int i = 0; i < 10; i++) {
			r.update(newRndVect(2, rnd), Math.random());
		}
		assertEquals(2, r.getCoefficients().size());
		assertEquals(2, r.getPrecisionMatrix().rowSize());
		assertEquals(2, r.getPrecisionMatrix().getRow(0).size());
		assertEquals(2, r.getPrecisionMatrix().getRow(1).size());

		r.appendParameters(1);
		assertEquals(3, r.getCoefficients().size());
		assertEquals(3, r.getPrecisionMatrix().rowSize());
		assertEquals(3, r.getPrecisionMatrix().getRow(0).size());
		assertEquals(3, r.getPrecisionMatrix().getRow(1).size());
		assertEquals(3, r.getPrecisionMatrix().getRow(2).size());

		assertEquals(0, r.getPrecisionMatrix().getRow(0).get(2));
		assertEquals(0, r.getPrecisionMatrix().getRow(1).get(2));
		assertEquals(0, r.getPrecisionMatrix().getRow(2).get(0));
		assertEquals(0, r.getPrecisionMatrix().getRow(2).get(1));
		assertEquals(1e6, r.getPrecisionMatrix().getRow(2).get(2));
	}

	// no real tests

	private static Vector newRndVect(int dim, Random rnd) {
		final Vector result = new Vector(dim);
		for (int i = 0; i < dim - 1; i++)
			result.set(i, rnd.nextGaussian());
		result.set(dim - 1, 1); // constant
		return result;
	}

	static void test10dimRandom() {
		final Random rnd = new Random();
		final int dim = 10;
		final int its = 25;
		final int runs = 1;

		for (int run = 0; run < runs; run++) {
			final Vector a = newRndVect(dim, rnd);
			final Regression r = new Regression(1.0, new Vector(dim), Matrix
					.newDiagonal(dim, 1e6));

			for (int it = 0; it < its; it++) {
				Vector x = newRndVect(dim, rnd);
				final double y = x.innerProd(a);
				final double e = y - x.innerProd(r.getCoefficients());

				// ----------------------------------------
				x = new Vector(dim);
				x.set(0, 1); // constant explanatory variable
				x.set(dim - 1, 1); // _the_ constant
				// ----------------------------------------

				System.out.println("it = " + it + "\terr = " + e * e
						+ "\tnorm = " + r.getPrecisionMatrix().frobeniusNorm());
				System.out.println(r.getCoefficients());
				System.out.println(r.getPrecisionMatrix());
				System.out.println();

				r.update(x, y);
			}
			System.out.println();
		}
	}

	// static void testConstantInput() {
	// final Regression r = new Regression(1.0, new Vector(2), Matrix
	// .newDiagonal(2, 1e6));
	// for (int it = 0; it < 20; it++) {
	// final Vector x = new Vector(it == 10 ? 1e0 : 1e-6, 1.0);
	// final double y = 2.0 + Math.random();
	// final double e = y - x.innerProd(r.getCoefficients());
	// System.out.println("it = " + it + ", err = " + e * e + ", norm = "
	// + r.getPrecisionMatrix().frobeniusNorm());
	// System.out.println(r.getCoefficients());
	// System.out.println(r.getPrecisionMatrix());
	// r.update(x, y);
	// }
	// }
	//
	// public static void main(String[] args) throws IOException {
	// testConstantInput();
	// }
}
