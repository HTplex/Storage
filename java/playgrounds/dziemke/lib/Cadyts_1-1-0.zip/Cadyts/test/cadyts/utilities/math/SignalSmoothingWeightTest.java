/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import static org.junit.Assert.*;

import org.junit.Test;

import cadyts.utilities.math.SignalSmoothingWeight;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class SignalSmoothingWeightTest {

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction() {
		new SignalSmoothingWeight(-.1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction2() {
		new SignalSmoothingWeight(1.1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction3() {
		new SignalSmoothingWeight(Double.NaN);
	}

	@Test
	public void testConstructionWithZeroInnovation() {
		final SignalSmoothingWeight ssw = new SignalSmoothingWeight(0.5);
		ssw.freeze();
		assertEquals(1.0, ssw.getNextInnovationWeight());
		assertEquals(1.0 / 2.0, ssw.getNextInnovationWeight());
		assertEquals(1.0 / 3.0, ssw.getNextInnovationWeight());
	}

	@Test
	public void testWeightSwitching() {
		final SignalSmoothingWeight ssw = new SignalSmoothingWeight(0.5);
		assertEquals(1.0, ssw.getNextInnovationWeight());
		assertEquals(0.5, ssw.getNextInnovationWeight());
		assertEquals(0.5, ssw.getNextInnovationWeight());

		ssw.freeze();
		assertEquals(1.0 / 3.0, ssw.getNextInnovationWeight());
		assertEquals(1.0 / 4.0, ssw.getNextInnovationWeight());
		
		ssw.freeze();
		assertEquals(1.0 / 5.0, ssw.getNextInnovationWeight());
		assertEquals(1.0 / 6.0, ssw.getNextInnovationWeight());
	}

	@Test
	public void testSignalSmoothingWeightConstant() {
		final SignalSmoothingWeight ssw = new SignalSmoothingWeight(0.95);
		assertEquals(1.0, ssw.getLastInnovationWeight());
		assertEquals(1.0, ssw.getLastInnovationWeight());
		ssw.getNextInnovationWeight();
		ssw.getNextInnovationWeight();
		ssw.getNextInnovationWeight();
		assertEquals(0.95, ssw.getLastInnovationWeight());
		assertEquals(0.95, ssw.getNextInnovationWeight());
	}

	@Test
	public void testFreeze() {
		final SignalSmoothingWeight ssw = new SignalSmoothingWeight(.5);
		ssw.freeze();
		for (int i = 0; i < 100; i++) {
			ssw.getNextInnovationWeight();
		}
		assertEquals(1.0 / 101.0, ssw.getLastInnovationWeight());
	}
}
