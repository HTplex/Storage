/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.junit.Assert;
import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class MultinomialLogitTest {

	/*
	 * numerical 1st derivative of choice probability w.r.t. coefficient
	 */
	private static double dProbi_dCoeffj(final MultinomialLogit mnl,
			final int i, final int j, final double eps) {
		final double coeff = mnl.getCoeff().get(j);

		mnl.setCoefficient(j, coeff + 0.5 * eps);
		final double p2 = mnl.getProbs().get(i);
		mnl.setCoefficient(j, coeff - 0.5 * eps);
		final double p1 = mnl.getProbs().get(i);
		mnl.setCoefficient(j, coeff);

		return (p2 - p1) / eps;
	}

	/*
	 * numerical first derivative of choice probabilities w.r.t. ASC
	 */
	private static double dProb_dASC(final MultinomialLogit mnl, final int i,
			final int i2, final double eps) {
		final double asc = mnl.getASC().get(i2);

		mnl.setASC(i2, asc + 0.5 * eps);
		final double p2 = mnl.getProbs().get(i);
		mnl.setASC(i2, asc - 0.5 * eps);
		final double p1 = mnl.getProbs().get(i);
		mnl.setASC(i2, asc);

		return (p2 - p1) / eps;
	}

	/*
	 * numerical second derivative of choice probability w.r.t. coefficients
	 */
	private static double d2Probi_dCoeffj1dCoeffj2(final MultinomialLogit mnl,
			final int i, final int j1, final int j2, final double eps) {
		final double coeff2 = mnl.getCoeff().get(j2);

		mnl.setCoefficient(j2, coeff2 + 0.5 * eps);
		final double dPi_dCoeffj1_Coeffj2Plus = mnl.get_dProb_dParameters(
				Arrays.asList(j1), false).getRow(i).get(0);
		mnl.setCoefficient(j2, coeff2 - 0.5 * eps);
		final double dPi_dCoeffj1_Coeffj2Minus = mnl.get_dProb_dParameters(
				Arrays.asList(j1), false).getRow(i).get(0);
		mnl.setCoefficient(j2, coeff2);

		return (dPi_dCoeffj1_Coeffj2Plus - dPi_dCoeffj1_Coeffj2Minus) / eps;
	}

	@Test
	public void testSensitivities() {
		final Random rnd = new Random(4711);

		for (int runs = 0; runs < 100; runs++) {

			/*
			 * create a random mnl
			 */
			final MultinomialLogit mnl = new MultinomialLogit(
					rnd.nextInt(5) + 1, rnd.nextInt(5) + 1);
			for (int j = 0; j < mnl.getAttrCount(); j++) {
				mnl.setCoefficient(j, rnd.nextGaussian());
			}
			for (int i = 0; i < mnl.getChoiceSetSize(); i++) {
				mnl.setASC(i, rnd.nextGaussian());
			}
			for (int i = 0; i < mnl.getChoiceSetSize(); i++) {
				for (int j = 0; j < mnl.getAttrCount(); j++) {
					mnl.setAttribute(i, j, rnd.nextGaussian());
				}
			}

			/*
			 * decide which sensitivities to test
			 */
			final List<Integer> attrIndices = new ArrayList<Integer>();
			final boolean fullAnalysis = rnd.nextBoolean();
			for (int j = 0; j < mnl.getAttrCount(); j++) {
				if (fullAnalysis || rnd.nextDouble() < 0.5) {
					attrIndices.add(j);
				}
			}

			/*
			 * test derivatives of probabilities w.r.t. coefficients
			 */
			for (int i = 0; i < mnl.getChoiceSetSize(); i++) {
				for (int j = 0; j < attrIndices.size(); j++) {
					final double analyt = mnl.get_dProb_dParameters(
							attrIndices, false).getRow(i).get(j);
					final double num = dProbi_dCoeffj(mnl, i, attrIndices
							.get(j), 1e-6);
					Assert.assertEquals(0, num - analyt, 1e-6);
				}
			}

			/*
			 * test derivatives of probabilities w.r.t ASCs
			 */
			for (int i = 0; i < mnl.getChoiceSetSize(); i++) {
				for (int i2 = 0; i2 < mnl.getChoiceSetSize(); i2++) {
					final double analyt = mnl.get_dProbs_dASCs().getRow(i).get(
							i2);
					final double num = dProb_dASC(mnl, i, i2, 1e-6);
					Assert.assertEquals(0, num - analyt, 1e-6);
				}
			}

			/*
			 * test 2nd derivatives of probabilities w.r.t. coefficients
			 */
			for (int i = 0; i < mnl.getChoiceSetSize(); i++) {
				for (int j1 = 0; j1 < attrIndices.size(); j1++) {
					for (int j2 = 0; j2 < attrIndices.size(); j2++) {
						final double analyt = mnl.get_d2P_dbdb(1e-6,
								attrIndices, false).get(i).getRow(j1).get(j2);
						final double num = d2Probi_dCoeffj1dCoeffj2(mnl, i,
								attrIndices.get(j1), attrIndices.get(j2), 1e-6);
						Assert.assertEquals(0, num - analyt, 1e-5);
					}
				}
			}
		}
	}
}
