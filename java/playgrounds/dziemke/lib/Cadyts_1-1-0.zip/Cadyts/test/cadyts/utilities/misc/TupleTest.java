/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import static org.junit.Assert.assertEquals;
import junit.framework.Assert;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class TupleTest {

	@Test(expected = IllegalArgumentException.class)
	public void testTuple1() {
		new Tuple<Integer, Integer>(null, 1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testTuple2() {
		new Tuple<Integer, Integer>(1, null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testTuple3() {
		new Tuple<Integer, Integer>(null, null);
	}

	@Test
	public void testTuple4() {
		new Tuple<String, Integer>("", 2);
		new Tuple<Double, String>(Math.PI, "test");
	}

	@Test
	public void testHashCode() {
		final String a = "hello";
		final Double b = Double.MAX_VALUE;

		final Tuple<Object, Object> t1 = new Tuple<Object, Object>(a, b);
		final Tuple<String, Double> t2 = new Tuple<String, Double>(a, b);

		Assert.assertEquals(t1.hashCode(), t1.hashCode());
		Assert.assertEquals(t1.hashCode(), t2.hashCode());
		Assert.assertEquals(t2.hashCode(), t2.hashCode());
	}

	@Test
	public void testGetA() {
		assertEquals("1", (new Tuple<String, String>("1", "2")).getA());
	}

	@Test
	public void testGetB() {
		assertEquals("2", (new Tuple<String, String>("1", "2")).getB());
	}

	@Test
	public void testEqualsObject() {

		final String a = "hello";
		final Double b = Double.MAX_VALUE;

		final Tuple<Object, Object> t1 = new Tuple<Object, Object>(a, b);
		final Tuple<String, Double> t2 = new Tuple<String, Double>(a, b);

		final Tuple<Object, Object> t3 = new Tuple<Object, Object>(b, a);
		final Tuple<Double, String> t4 = new Tuple<Double, String>(b, a);

		Assert.assertEquals(t1, t1);
		Assert.assertEquals(t1, t2);
		Assert.assertEquals(t2, t2);

		Assert.assertEquals(t3, t3);
		Assert.assertEquals(t3, t4);
		Assert.assertEquals(t4, t4);

		Assert.assertFalse(t1.equals(null));
		Assert.assertFalse(t2.equals(null));
		Assert.assertFalse(t3.equals(null));
		Assert.assertFalse(t4.equals(null));

		Assert.assertFalse(t1.equals(t3));
		Assert.assertFalse(t1.equals(t4));
		Assert.assertFalse(t2.equals(t3));
		Assert.assertFalse(t2.equals(t4));
	}
}
