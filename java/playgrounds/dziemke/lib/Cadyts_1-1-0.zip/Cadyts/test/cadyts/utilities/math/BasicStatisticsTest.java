/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import junit.framework.Assert;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class BasicStatisticsTest {

	@Test
	public void test1() {
		final double[] data = new double[] { 0, 2.5, -1.5 };
		final BasicStatistics bs = new BasicStatistics();
		Assert.assertEquals(0, bs.size());
		for (double val : data) {
			bs.add(val);
		}
		final double mean = (data[0] + data[1] + data[2]) / 3.0;
		final double var = ((data[0] - mean) * (data[0] - mean)
				+ (data[1] - mean) * (data[1] - mean) + (data[2] - mean)
				* (data[2] - mean)) / 2.0;
		final double min = Math.min(data[0], Math.min(data[1], data[2]));
		final double max = Math.max(data[0], Math.max(data[1], data[2]));
		Assert.assertEquals(mean, bs.getAvg(), 1e-6);
		Assert.assertEquals(var, bs.getVar(), 1e-6);
		Assert.assertEquals(Math.sqrt(var), bs.getStddev(), 1e-6);
		Assert.assertEquals(min, bs.getMin(), 1e-6);
		Assert.assertEquals(max, bs.getMax(), 1e-6);
		Assert.assertEquals(3, bs.size());
		bs.clear();
		Assert.assertEquals(0, bs.size());
	}
}
