/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNull;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class StatisticsTrackerTest {

	@Test
	public void testStatisticsTracker() throws IOException {
		final String filename = "testfile982349823283470.txt";
		/*
		 * (1) generate file
		 */
		final StatisticsTracker st = new StatisticsTracker(filename);
		// line 1
		st.clear();
		st.writeToFile();
		// line 2
		st.clear();
		st.registerSingleLinkLL(1.2);
		st.writeToFile();
		// line 3
		st.clear();
		st.registerSingleLinkLLPredError(3.4);
		st.writeToFile();
		// line 4
		st.clear();
		st.registerLinkLambda(5.6);
		st.writeToFile();
		// line 5
		st.clear();
		st.registerPlanLambda(7.8);
		st.writeToFile();
		// line 6
		st.clear();
		st.registerLinkLambda(-1.0);
		st.registerLinkLambda(2.0);
		st.writeToFile();
		// line 7
		st.clear();
		st.registerPlanLambda(-2.0);
		st.registerPlanLambda(1.0);
		st.writeToFile();
		// line 8
		st.clear();
		st.registerChoice();
		st.writeToFile();
		// line 9
		st.clear();
		st.registerMultiLinkLL(2);
		st.writeToFile();
		// line 9
		st.clear();
		st.registerSingleLinkLL(-10.0);
		st.registerMultiLinkLL(-1.1);
		st.writeToFile();
		
		/*
		 * (2) check file content
		 */

		final BufferedReader reader = new BufferedReader(new FileReader(
				filename));
		assertEquals(
				"count-ll\tcount-ll-pred-err\tp2p-ll\ttotal-ll\tlink-lambda-avg\tlink-lambda-stddev\tlink-lambda-min\tlink-lambda-max\tplan-lambda-avg\tplan-lambda-stddev\tplan-lambda-min\tplan-lambda-max\treplan-count",
				reader.readLine());
		assertEquals("--\t--\t--\t--\t--\t--\t--\t--\t--\t--\t--\t--\t0",
				reader.readLine());
		assertEquals("1.2\t--\t--\t1.2\t--\t--\t--\t--\t--\t--\t--\t--\t0",
				reader.readLine());
		assertEquals("--\t3.4\t--\t--\t--\t--\t--\t--\t--\t--\t--\t--\t0",
				reader.readLine());
		assertEquals(
				"--\t--\t--\t--\t5.6\tInfinity\t5.6\t5.6\t--\t--\t--\t--\t0",
				reader.readLine());
		assertEquals(
				"--\t--\t--\t--\t--\t--\t--\t--\t7.8\tInfinity\t7.8\t7.8\t0",
				reader.readLine());
		assertEquals(
				"--\t--\t--\t--\t0.5\t2.1213203435596424\t-1.0\t2.0\t--\t--\t--\t--\t0",
				reader.readLine());
		assertEquals(
				"--\t--\t--\t--\t--\t--\t--\t--\t-0.5\t2.1213203435596424\t-2.0\t1.0\t0",
				reader.readLine());
		assertEquals("--\t--\t--\t--\t--\t--\t--\t--\t--\t--\t--\t--\t1",
				reader.readLine());
		assertEquals("--\t--\t2.0\t2.0\t--\t--\t--\t--\t--\t--\t--\t--\t0",
				reader.readLine());
		assertEquals("-10.0\t--\t-1.1\t-11.1\t--\t--\t--\t--\t--\t--\t--\t--\t0",
				reader.readLine());
		assertNull(reader.readLine());
		/*
		 * (3) clean up
		 */
		reader.close();
		new File(filename).delete();
	}
}
