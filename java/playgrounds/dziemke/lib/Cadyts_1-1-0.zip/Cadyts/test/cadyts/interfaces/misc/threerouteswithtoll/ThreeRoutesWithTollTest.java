/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */
package cadyts.interfaces.misc.threerouteswithtoll;

import static junit.framework.Assert.assertEquals;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class ThreeRoutesWithTollTest {

	@Test
	public void testScenario() {

		final ThreeRoutesWithTollScenario test = new ThreeRoutesWithTollScenario();
		test.runEstimation();

		assertEquals(2, test.result.size());
		assertEquals(-0.7531969384276298, test.result.get(0));
		assertEquals(-0.7488549519014317, test.result.get(1));

		assertEquals(2, test.covariance.rowSize());
		assertEquals(2, test.covariance.columnSize());
		assertEquals(0.0032271353270451036, test.covariance.getRow(0).get(0));
		assertEquals(-3.1111382702799786E-4, test.covariance.getRow(0).get(1));
		assertEquals(-3.1111382702799786E-4, test.covariance.getRow(1).get(0));
		assertEquals(0.006286680073209947, test.covariance.getRow(1).get(1));
	}
}
