/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.Test;

import cadyts.utilities.misc.SimpleLogFormatter;
import cadyts.utilities.misc.StreamFlushHandler;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class StreamFlushHandlerTest extends StreamFlushHandler {

	private int flushes = 0;

	public StreamFlushHandlerTest() {
		super(new OutputStream() {
			@Override
			public void write(int b) throws IOException {
			}
		}, new SimpleLogFormatter(""));
	}

	@Override
	public void flush() {
		super.flush();
		this.flushes++;
	}

	@Test
	public void testFlushCount() {
		final Logger l = Logger.getLogger("test");
		l.setUseParentHandlers(false);

		final StreamFlushHandlerTest sfh = new StreamFlushHandlerTest();
		l.addHandler(sfh);

		Assert.assertEquals(0, sfh.flushes);
		l.info("blah");
		Assert.assertEquals(1, sfh.flushes);
		l.warning("more blah");
		Assert.assertEquals(2, sfh.flushes);
		sfh.flush();
		Assert.assertEquals(3, sfh.flushes);
	}
}
