/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.demand;

import static org.junit.Assert.*;

import org.junit.Test;

import cadyts.demand.ODRelation;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class ODRelationTest {

	@Test(expected = IllegalArgumentException.class)
	public void testODRelation1() {
		new ODRelation<Integer>(null, 1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testODRelation2() {
		new ODRelation<Integer>(1, null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testODRelation3() {
		new ODRelation<Integer>(null, null);
	}

	@Test
	public void testODRelation4() {
		new ODRelation<String>("", "");
		new ODRelation<String>("od1", "od2");
		new ODRelation<Integer>(Integer.MIN_VALUE, Integer.MAX_VALUE);
	}

	@Test
	public void testHashCode() {
		final ODRelation<Integer> od1 = new ODRelation<Integer>(1, 2);
		final ODRelation<Integer> od2 = new ODRelation<Integer>(1, 2);
		assertEquals(od1.hashCode(), od2.hashCode());
		assertEquals(od1.hashCode(), od1.hashCode());
		assertEquals(od2.hashCode(), od2.hashCode());
	}

	@Test
	public void testGetFromTAZ() {
		assertEquals("1", (new ODRelation<String>("1", "2")).getFromTAZ());
	}

	@Test
	public void testGetToTAZ() {
		assertEquals("2", (new ODRelation<String>("1", "2")).getToTAZ());
	}

	@Test
	public void testEqualsObject() {
		final ODRelation<Integer> od1 = new ODRelation<Integer>(1, 2);
		final ODRelation<Integer> od2 = new ODRelation<Integer>(1, 2);
		assertEquals(od1, od2);
		assertEquals(od1, od1);
		assertEquals(od2, od2);
		assertFalse(od1.equals(new ODRelation<Integer>(1, 3)));
		assertFalse(od1.equals(new ODRelation<Integer>(0, 2)));
		assertFalse(od1.equals(new ODRelation<Integer>(0, 3)));
		assertFalse(od1.equals("gaga"));
		assertFalse(od2.equals(null));
	}
}
