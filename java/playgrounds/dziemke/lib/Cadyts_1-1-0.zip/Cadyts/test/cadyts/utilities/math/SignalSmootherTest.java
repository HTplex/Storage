/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import org.junit.Assert;
import org.junit.Test;

import cadyts.utilities.math.SignalSmoother;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class SignalSmootherTest {

	@Test(expected = IllegalArgumentException.class)
	public void testSignalSmoother() {
		new SignalSmoother(-1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSignalSmoother2() {
		new SignalSmoother(2);
	}

	@Test
	public void testJumpResponse1() {
		final SignalSmoother ss = new SignalSmoother(0.1);
		ss.addValue(0);
		for (int i = 0; i < 10; i++) {
			ss.addValue(1);
		}
		Assert.assertEquals(1.0 - Math.pow(0.9, 10), ss.getSmoothedValue());
	}

	@Test
	public void testJumpResponse2() {
		final SignalSmoother ss = new SignalSmoother(0.1);
		ss.addValue(0);
		for (int i = 0; i < 10; i++) {
			ss.addValue(-1);
			ss.addValue(+2);
		}
		Assert.assertEquals(0.5, ss.getSmoothedValue());
	}
}
