/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import org.junit.Assert;
import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class TimeTest {

	@Test
	public void testSecFromStr() {
		Assert.assertEquals(0, Time.secFromStr("0:0:0"));
		Assert.assertEquals(0, Time.secFromStr("00:00:00"));
		Assert.assertEquals(1, Time.secFromStr("0:0:1"));
		Assert.assertEquals(60, Time.secFromStr("0:1:0"));
		Assert.assertEquals(3600, Time.secFromStr("1:0:0"));
		Assert.assertEquals(23 * 3600 + 59 * 60 + 59, Time
				.secFromStr("23:59:59"));
		Assert.assertEquals(23 * 3600 + 59 * 60, Time.secFromStr("23:59"));
		Assert.assertEquals(24 * 3600, Time.secFromStr("24:0:0"));
		Assert.assertEquals(24 * 3600, Time.secFromStr("24:0"));
		for (int i = 0; i < 86400; i += 10000) {
			Assert.assertEquals(i, Time.secFromStr(Integer.toString(i)));
		}
	}

	@Test
	public void testStrFromSec() {
		Assert.assertEquals("00:00:00", Time.strFromSec(0));
		Assert.assertEquals("00:00:01", Time.strFromSec(1));
		Assert.assertEquals("00:01:00", Time.strFromSec(60));
		Assert.assertEquals("01:00:00", Time.strFromSec(3600));
		Assert.assertEquals("23:59:59", Time.strFromSec(23 * 3600 + 59 * 60
				+ 59));
		Assert.assertEquals("24:00:00", Time.strFromSec(24 * 3600));
	}
}
