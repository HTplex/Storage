/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */
package cadyts.interfaces.matsim;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import cadyts.demand.Plan;
import cadyts.interfaces.TwoRoutesScenarioSkeleton;
import cadyts.measurements.SingleLinkMeasurement;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
class MATSimTestScenario extends TwoRoutesScenarioSkeleton {

	// -------------------- MEMBERS --------------------

	private final MATSimUtilityModificationCalibrator<String> calibrator;

	final List<Double> flowRoute1_veh;

	// -------------------- CONSTRUCTION --------------------

	MATSimTestScenario() {
		this.calibrator = new MATSimUtilityModificationCalibrator<String>(
				new Random(4711), 0.95);
		this.calibrator.setFreezeIteration(20);
		this.calibrator.setDebugMode(false);
		this.calibrator.setStatisticsFile("calibration-stats.txt");
		this.calibrator.setProportionalAssignment(false);

		this.flowRoute1_veh = new ArrayList<Double>();
	}

	// -------------------- SIMULATED SIMULATION --------------------

	public void run() {

		this.calibrator.addMeasurement(LINK_1, START_S, END_S, this.y1_veh,
				this.stddev1_veh, SingleLinkMeasurement.TYPE.COUNT_VEH);

		List<Plan<String>> choiceSet = this.choiceSet();
		List<List<Double>> allTravelTimes = new ArrayList<List<Double>>();

		List<Double> initialTravelTimes = new ArrayList<Double>();
		initialTravelTimes.add(this.minTT);
		initialTravelTimes.add(this.minTT);
		allTravelTimes.add(initialTravelTimes);

		final int its = 100;
		for (int i = 0; i < its; i++) {

			/*
			 * utility correction for average travel times
			 */
			final List<Double> travelTimes = this
					.averageTravelTimes(allTravelTimes);
			double offset1 = this.calibrator.getUtilityCorrection(choiceSet
					.get(0));
			double offset2 = this.calibrator.getUtilityCorrection(choiceSet
					.get(1));
			travelTimes.set(0, travelTimes.get(0) + offset1 / this.mu);
			travelTimes.set(1, travelTimes.get(1) + offset2 / this.mu);

			/*
			 * choice
			 */
			final List<Double> routeProbs = this.routeProbs(travelTimes);
			final List<Plan<String>> choices = new ArrayList<Plan<String>>(
					this.popSize);
			for (int n = 0; n < this.popSize; n++) {
				if (this.calibrator.getRandom().nextDouble() < routeProbs
						.get(0)) {
					choices.add(choiceSet.get(0));
					this.calibrator.registerChoice(choiceSet.get(0));
				} else {
					choices.add(choiceSet.get(1));
					this.calibrator.registerChoice(choiceSet.get(1));
				}
			}

			/*
			 * network loading
			 */
			final List<Double> routeFlows = this.routeFlows(choices);
			this.flowRoute1_veh.add(routeFlows.get(0));
			this.calibrator.afterNetworkLoading(this.simResults(routeFlows));
			allTravelTimes.add(this.travelTimes(routeFlows));
		}
	}

	// -------------------- MAIN --------------------

	// public static void main(String[] args) {
	// System.out.println("STARTED...");
	// final MATSimTestScenario test = new MATSimTestScenario();
	// test.run();
	// System.out.println(test.flowRoute1_veh);
	// System.out.println("...DONE");
	// }
}
