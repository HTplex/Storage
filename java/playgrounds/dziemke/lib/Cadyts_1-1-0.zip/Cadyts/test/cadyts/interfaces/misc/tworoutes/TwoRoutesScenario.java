/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */
package cadyts.interfaces.misc.tworoutes;

import java.util.ArrayList;
import java.util.List;

import cadyts.calibrators.analytical.AnalyticalCalibrator;
import cadyts.demand.Plan;
import cadyts.interfaces.TwoRoutesScenarioSkeleton;
import cadyts.measurements.SingleLinkMeasurement;
import cadyts.utilities.math.Vector;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
class TwoRoutesScenario extends TwoRoutesScenarioSkeleton {

	// -------------------- MEMBERS --------------------

	private final AnalyticalCalibrator<String> calibrator;

	List<Double> flowRoute1_veh = new ArrayList<Double>();

	List<Double> lambda1 = new ArrayList<Double>();

	// -------------------- CONSTRUCTION --------------------

	TwoRoutesScenario() {
		this.calibrator = new AnalyticalCalibrator<String>(
				"calibration-log.txt", 42L, END_S);
		calibrator.setRegressionInertia(0.95);
		calibrator.setProportionalAssignment(true);
		calibrator.setFreezeIteration(0);
		calibrator.setMinStddev(1, SingleLinkMeasurement.TYPE.FLOW_VEH_H);
	}

	// -------------------- SIMULATION --------------------

	void run() {

		this.calibrator.addMeasurement(LINK_1, START_S, END_S, this.y1_veh,
				this.stddev1_veh, SingleLinkMeasurement.TYPE.COUNT_VEH);

		List<Plan<String>> choiceSet = this.choiceSet();
		List<List<Double>> allTravelTimes = new ArrayList<List<Double>>();

		List<Double> initialTravelTimes = new ArrayList<Double>();
		initialTravelTimes.add(this.minTT);
		initialTravelTimes.add(this.minTT);
		allTravelTimes.add(initialTravelTimes);

		for (int it = 0; it < this.maxIts; it++) {
			/*
			 * choice probabilities from average travel times
			 */
			final List<Double> travelTimes = this
					.averageTravelTimes(allTravelTimes);
			final List<Double> routeProbs = this.routeProbs(travelTimes);
			/*
			 * choice
			 */
			final List<Plan<String>> choices = new ArrayList<Plan<String>>(
					this.popSize);
			for (int n = 0; n < this.popSize; n++) {
				this.calibrator.selectPlan(choiceSet, new Vector(routeProbs));
				choices
						.add(choiceSet
								.get(this.calibrator.getLastChoiceIndex()));
			}
			/*
			 * network loading
			 */
			final List<Double> routeFlows = this.routeFlows(choices);
			this.flowRoute1_veh.add(routeFlows.get(0));
			this.lambda1.add(this.calibrator.calcLinearPlanEffect(choiceSet
					.get(0)));
			this.calibrator.afterNetworkLoading(this.simResults(routeFlows));
			allTravelTimes.add(this.travelTimes(routeFlows));
		}
	}

	// -------------------- MAIN-FUNCTION, ONLY FOR TESTING --------------------

	// public static void main(String[] args) {
	// final TwoRoutesScenario test = new TwoRoutesScenario();
	// test.y1_veh = 250;
	// test.stddev1_veh = 10;
	// test.run();
	// System.out.println(test.flowRoute1_veh);
	// System.out.println(test.lambda1);
	// }
}
