/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class MatrixTest {

	/*-
	 * 1  1
	 * 1  1
	 */
	private Matrix allOne = null;

	/*-
	 * 1  0
	 * 0  1
	 */
	private Matrix identity = null;

	/*-
	 *  1.0  -1.0
	 * -2.0   0.5
	 */
	private Matrix general = null;

	@Before
	public void setup() {
		this.allOne = new Matrix(2, 2);
		this.allOne.getRow(0).set(0, 1);
		this.allOne.getRow(0).set(1, 1);
		this.allOne.getRow(1).set(0, 1);
		this.allOne.getRow(1).set(1, 1);

		this.identity = new Matrix(2, 2);
		this.identity.getRow(0).set(0, 1);
		this.identity.getRow(1).set(1, 1);

		this.general = new Matrix(2, 2);
		this.general.getRow(0).set(0, 1);
		this.general.getRow(0).set(1, -1);
		this.general.getRow(1).set(0, -2);
		this.general.getRow(1).set(1, .5);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction1() {
		new Matrix(0, 1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction2() {
		new Matrix(1, 0);
	}

	@Test
	public void testConstruction3() {
		new Matrix(1, 1);
	}

	@Test
	public void testNewDiagonal() {
		final Matrix result = Matrix.newDiagonal(2, 1);
		assertEquals(1, result.getRow(0).get(0));
		assertEquals(0, result.getRow(0).get(1));
		assertEquals(0, result.getRow(1).get(0));
		assertEquals(1, result.getRow(1).get(1));
	}

	@Test
	public void testNewDiagonalVector() {
		final Matrix result = Matrix.newDiagonal(new Vector(-1.2, 3.4));
		assertEquals(-1.2, result.getRow(0).get(0));
		assertEquals(0, result.getRow(0).get(1));
		assertEquals(0, result.getRow(1).get(0));
		assertEquals(3.4, result.getRow(1).get(1));
	}

	@Test(expected = UnsupportedOperationException.class)
	public void testNewImmutableView1() {
		Matrix m = this.general.newImmutableView();
		m.clear();
	}

	@Test(expected = UnsupportedOperationException.class)
	public void testNewImmutableView2() {
		Matrix m = this.general.newImmutableView();
		m.getRow(0).set(0, 1.23);
	}

	@Test
	public void testFrobeniusNorm() {
		assertEquals(Math.sqrt(2), this.identity.frobeniusNorm());
		assertEquals(Math.sqrt(4), this.allOne.frobeniusNorm());
	}

	@Test
	public void testClear() {
		this.general.clear();
		assertEquals(2, this.general.rowSize());
		assertEquals(2, this.general.columnSize());
		assertEquals(0.0, this.general.getRow(0).get(0));
		assertEquals(0.0, this.general.getRow(0).get(1));
		assertEquals(0.0, this.general.getRow(1).get(0));
		assertEquals(0.0, this.general.getRow(1).get(1));
	}

	@Test
	public void testAdd1() {
		this.general.add(this.general, -1.0);
		assertEquals(0.0, this.general.getRow(0).get(0));
		assertEquals(0.0, this.general.getRow(0).get(1));
		assertEquals(0.0, this.general.getRow(1).get(0));
		assertEquals(0.0, this.general.getRow(1).get(1));
	}

	@Test
	public void testAdd2() {
		this.general.add(this.identity, 1.0);
		assertEquals(2.0, this.general.getRow(0).get(0));
		assertEquals(-1.0, this.general.getRow(0).get(1));
		assertEquals(-2.0, this.general.getRow(1).get(0));
		assertEquals(1.5, this.general.getRow(1).get(1));
	}

	@Test
	public void testMult() {
		this.general.mult(2.0);
		assertEquals(2, this.general.getRow(0).get(0));
		assertEquals(-2, this.general.getRow(0).get(1));
		assertEquals(-4, this.general.getRow(1).get(0));
		assertEquals(1, this.general.getRow(1).get(1));
	}

	@Test
	public void testAddOuterProduct() {
		this.allOne.addOuterProduct(new Vector(1, 2), new Vector(3, 4), 1.0);
		assertEquals(4, this.allOne.getRow(0).get(0));
		assertEquals(5, this.allOne.getRow(0).get(1));
		assertEquals(7, this.allOne.getRow(1).get(0));
		assertEquals(9, this.allOne.getRow(1).get(1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddOuterProduct2() {
		this.allOne.addOuterProduct(new Vector(1.0), new Vector(3.0, 4.0), 1.0);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddOuterProduct3() {
		this.allOne.addOuterProduct(new Vector(1.0, 2.0), new Vector(3.0), 1.0);
	}

	@Test
	public void testTimesVectorFromLeft() {
		final Vector result = this.general.timesVectorFromLeft(new Vector(-2.0,
				4.0));
		assertEquals(-10, result.get(0));
		assertEquals(4.0, result.get(1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testTimesVectorFromLeft2() {
		this.general.timesVectorFromLeft(new Vector(4.0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testTimesVectorFromLeft3() {
		this.general.timesVectorFromLeft(new Vector(-2.0, 4.0, 6.0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testTimesVectorFromLeft4() {
		this.general.timesVectorFromLeft(new Vector(-2.0, 4.0), new Vector(1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testTimesVectorFromLeft5() {
		this.general.timesVectorFromLeft(new Vector(-2.0, 4.0), new Vector(3));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testEnlarge1() {
		this.general.copyEnlarged(-1, 0);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testEnlarge2() {
		this.general.copyEnlarged(0, -1);
	}

	@Test
	public void testCopy() {
		final Matrix other = this.general.copy();
		assertEquals(other.getRow(0).get(0), this.general.getRow(0).get(0));
		assertEquals(other.getRow(0).get(1), this.general.getRow(0).get(1));
		assertEquals(other.getRow(1).get(0), this.general.getRow(1).get(0));
		assertEquals(other.getRow(1).get(1), this.general.getRow(1).get(1));
	}

	@Test
	public void testEnlarge3() {
		final Matrix copy = this.general.copyEnlarged(0, 0);
		assertEquals(this.general.rowSize(), copy.rowSize());
		assertEquals(this.general.getRow(0).size(), copy.getRow(0).size());
		assertEquals(this.general.getRow(1).size(), copy.getRow(1).size());
		assertEquals(this.general.getRow(0).get(0), copy.getRow(0).get(0));
		assertEquals(this.general.getRow(0).get(1), copy.getRow(0).get(1));
		assertEquals(this.general.getRow(1).get(0), copy.getRow(1).get(0));
		assertEquals(this.general.getRow(1).get(1), copy.getRow(1).get(1));
	}

	@Test
	public void testEnlarge4() {
		final Matrix copy = this.general.copyEnlarged(2, 3);
		assertEquals(this.general.rowSize() + 2, copy.rowSize());
		assertEquals(this.general.getRow(0).size() + 3, copy.getRow(0).size());
		assertEquals(this.general.getRow(0).size() + 3, copy.getRow(1).size());
		assertEquals(this.general.getRow(0).size() + 3, copy.getRow(2).size());
		assertEquals(this.general.getRow(0).size() + 3, copy.getRow(3).size());
		assertEquals(this.general.getRow(0).get(0), copy.getRow(0).get(0));
		assertEquals(this.general.getRow(0).get(1), copy.getRow(0).get(1));
		assertEquals(this.general.getRow(1).get(0), copy.getRow(1).get(0));
		assertEquals(this.general.getRow(1).get(1), copy.getRow(1).get(1));
	}

	@Test
	public void testRound() {
		// test that every entry is reached and rounding of negative numbers --
		// everything else is tested in VectorTest
		final Matrix m = new Matrix(3, 1);
		m.getRow(0).set(0, -1.2);
		m.getRow(1).set(0, -3.5);
		m.getRow(2).set(0, -3.51);
		m.round(0);
		assertEquals(-1.0, m.getRow(0).get(0));
		assertEquals(-3.0, m.getRow(1).get(0));
		assertEquals(-4.0, m.getRow(2).get(0));
	}

	@Test
	public void testSymmetrize1() {
		this.allOne.symmetrize();
		assertEquals(1.0, this.allOne.getRow(0).get(0));
		assertEquals(1.0, this.allOne.getRow(0).get(1));
		assertEquals(1.0, this.allOne.getRow(1).get(0));
		assertEquals(1.0, this.allOne.getRow(1).get(1));
	}

	@Test
	public void testSymmetrize2() {
		this.identity.symmetrize();
		assertEquals(1.0, this.identity.getRow(0).get(0));
		assertEquals(0.0, this.identity.getRow(0).get(1));
		assertEquals(0.0, this.identity.getRow(1).get(0));
		assertEquals(1.0, this.identity.getRow(1).get(1));
	}

	@Test
	public void testSymmetrize3() {
		this.general.symmetrize();
		assertEquals(1.0, this.general.getRow(0).get(0));
		assertEquals(-1.5, this.general.getRow(0).get(1));
		assertEquals(-1.5, this.general.getRow(1).get(0));
		assertEquals(0.5, this.general.getRow(1).get(1));
	}

	@Test
	public void testSetColumn() {
		this.general.setColumn(0, new Vector(100.0, 1000.0));
		this.general.setColumn(1, new Vector(-99.9, +12.34));
		assertEquals(100.0, this.general.getRow(0).get(0));
		assertEquals(1000.0, this.general.getRow(1).get(0));
		assertEquals(-99.9, this.general.getRow(0).get(1));
		assertEquals(12.34, this.general.getRow(1).get(1));
	}

	@Test
	public void testIsAllZeros1() {
		assertTrue((new Matrix(2, 2)).isAllZeros());
	}

	@Test
	public void testIsAllZeros2() {
		assertFalse(this.general.isAllZeros());
	}

	@Test
	public void testIsAllZeros3() {
		assertFalse(this.identity.isAllZeros());
	}

	@Test
	public void testToSingleLineString() {
		assertEquals("[[ 1.0 -1.0 ][ -2.0 0.5 ]]", this.general
				.toSingleLineString());
	}

	@Test
	public void testTimesVectorFromRight() {
		final Vector result = this.general.timesVectorFromRight(new Vector(1.5,
				-2.0));
		assertEquals(2, result.size());
		assertEquals(3.5, result.get(0));
		assertEquals(-4.0, result.get(1));
	}
	
	@Test
	public void testNewTransposed1() {
		this.general = this.general.newTransposed();
		assertEquals(1.0, this.general.getRow(0).get(0));
		assertEquals(-2.0, this.general.getRow(0).get(1));
		assertEquals(-1.0, this.general.getRow(1).get(0));
		assertEquals(0.5, this.general.getRow(1).get(1));

	}

	@Test
	public void testNewTransposed2() {
		this.general = this.general.newTransposed().newTransposed();
		assertEquals(1.0, this.general.getRow(0).get(0));
		assertEquals(-1.0, this.general.getRow(0).get(1));
		assertEquals(-2.0, this.general.getRow(1).get(0));
		assertEquals(0.5, this.general.getRow(1).get(1));
	}

	@Test
	public void testToString() {
		assertEquals("[ 1.0 1.0 ]\n[ 1.0 1.0 ]", this.allOne.toString());
		assertEquals("[ 1.0 0.0 ]\n[ 0.0 1.0 ]", this.identity.toString());
		assertEquals("[ 1.0 -1.0 ]\n[ -2.0 0.5 ]", this.general.toString());
	}

	@Test
	public void testNewTransposed() {
		final Matrix m = new Matrix(3, 2);
		m.getRow(0).set(0, 00);
		m.getRow(0).set(1, 01);
		m.getRow(1).set(0, 10);
		m.getRow(1).set(1, 11);
		m.getRow(2).set(0, 20);
		m.getRow(2).set(1, 21);
		final Matrix t = m.newTransposed();
		assertEquals(2, t.rowSize());
		assertEquals(3, t.columnSize());

		assertEquals(00, t.getRow(0).get(0));
		assertEquals(10, t.getRow(0).get(1));
		assertEquals(20, t.getRow(0).get(2));
		assertEquals(01, t.getRow(1).get(0));
		assertEquals(11, t.getRow(1).get(1));
		assertEquals(21, t.getRow(1).get(2));
	}

	@Test
	public void testProduct1() {
		final Matrix _A = new Matrix(2, 1);
		_A.getRow(0).set(0, 1);
		_A.getRow(1).set(0, 2);
		final Matrix _B = new Matrix(1, 2);
		_B.getRow(0).set(0, 3);
		_B.getRow(0).set(1, 4);
		final Matrix _C = Matrix.product(_A, _B);
		assertEquals(3, _C.getRow(0).get(0));
		assertEquals(4, _C.getRow(0).get(1));
		assertEquals(6, _C.getRow(1).get(0));
		assertEquals(8, _C.getRow(1).get(1));
	}

	@Test
	public void testProduct2() {
		final Matrix _A = new Matrix(2, 2);
		_A.getRow(0).set(0, 1);
		_A.getRow(0).set(1, 2);
		_A.getRow(1).set(0, 3);
		_A.getRow(1).set(1, 4);
		final Matrix _B = new Matrix(2, 2);
		_B.getRow(0).set(0, -1);
		_B.getRow(0).set(1, -2);
		_B.getRow(1).set(0, -3);
		_B.getRow(1).set(1, -4);
		final Matrix _C = Matrix.product(_A, _B);
		assertEquals(-7, _C.getRow(0).get(0));
		assertEquals(-10, _C.getRow(0).get(1));
		assertEquals(-15, _C.getRow(1).get(0));
		assertEquals(-22, _C.getRow(1).get(1));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testProduct3() {
		final Matrix _A = new Matrix(2, 1);
		final Matrix _B = new Matrix(2, 1);
		Matrix.product(_A, _B);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testProduct4() {
		final Matrix _A = new Matrix(1, 2);
		final Matrix _B = new Matrix(1, 2);
		Matrix.product(_A, _B);
	}

}
