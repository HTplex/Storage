/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;

import org.junit.Test;

import cadyts.utilities.misc.DynamicData;
import cadyts.utilities.misc.DynamicDataXMLFileIO;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class DynamicDataXMLFileIOTest extends DynamicDataXMLFileIO<String> {

	private static final long serialVersionUID = 1L;

	@Override
	protected String attrValue2key(String string) {
		return string;
	}

	@Override
	protected String key2attrValue(String key) {
		return key;
	}

	@Test
	public void testWriteRead() throws Exception {
		
		final String name = "testfile8923749952123349634";
		if (new File(name).exists()) {
			fail("file " + name + " already exists");
		}

		final DynamicData<String> expected = new DynamicData<String>(0, 3600, 3);
		expected.put("x", 0, 0);
		expected.put("x", 1, 1);
		expected.put("x", 2, 2);
		(new DynamicDataXMLFileIOTest()).write(name, expected);

		final DynamicData<String> actual = (new DynamicDataXMLFileIOTest())
				.read(name);
		assertEquals(expected.getStartTime_s(), actual.getStartTime_s());
		assertEquals(expected.getBinSize_s(), actual.getBinSize_s());
		assertEquals(expected.getBinCnt(), actual.getBinCnt());
		for (int t = 0; t < 3600 * 5; t += 1000) {
			assertEquals(expected.getSum("x", t, t + 1000), actual.getSum("x",
					t, t + 1000));
			assertEquals(expected.getSum("y", t, t + 1000), actual.getSum("y",
					t, t + 1000));
		}

		(new File(name)).delete();
	}
}
