#
# Cadyts - Calibration of dynamic traffic simulations
#
# Copyright 2009, 2010 Gunnar Fl�tter�d
#
#
# This file is part of Cadyts.
#
# Cadyts is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Cadyts is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
#
# contact: gunnar.floetteroed@epfl.ch
#

#
# This script controls the interactions between DRACULA and Cadyts.
#
# Put in here the parameters of the simulation/calibration. If all goes well,
# this is the only section where you have to change something.
#

ITERATIONS  = 100;
FREEZEIT    = 40;
DEMANDSCALE = 1.5;
BINSIZE     = 900;
BETA_TT     = -0.01;
MIN_STDDEV  = 1.0;

NETWORK  = "net1";

DATA_DIR = "C:\\dracula\\" + NETWORK + "\\"; 

DRACPREP = "C:\\dracula\\dracwin\\dracprep.exe";
DRACSIM  = "C:\\dracula\\dracsim-auto.exe";
CADYTS   = "C:\\dracula\\DraculaController_v1-1.jar";

#
# The remainder of this skript should work without adjustments.
#

import os;
import shutil;

def run(call):
	print "executing \"" + call + "\" ...";
	code = os.system(call);
	print "... exited with return code", code;
	print;

def nextWhitespace(line):
	result = 0;
	while ((result < len(line)) and (not line[result].isspace())):
		result = result + 1;
	return result;

print;
print "------------------------------------------------------------";
print "Saving the original .PAR file as .PAR.ORG and writing a";
print "modified .PAR.MOD file in which the demand is scaled";
print "up by a factor of", DEMANDSCALE,". Also, extracting some simulation";
print "parameters to pass on to the calibration.";
print "------------------------------------------------------------";
print;

PARAMETERS_START = "PARAMETERS";
PARAMETERS_END   = "END";
GONZO_PREP       = "GONZO_PREP";
NSTEP            = "NSTEP";
TSTEP            = "TSTEP";
TWARM            = "TWARM";
TMAIN            = "TMAIN";

CURRENT_PAR  = NETWORK + ".PAR";
MODIFIED_PAR = NETWORK + ".PAR.MOD";
ORIGINAL_PAR = NETWORK + ".PAR.ORG";

os.chdir(DATA_DIR);

shutil.move(CURRENT_PAR, ORIGINAL_PAR);

fRead  = open(ORIGINAL_PAR, 'r');
fWrite = open(MODIFIED_PAR, 'w'); 

active = False;
for line in fRead:
	if not active:
		if (line.lstrip().upper().startswith(PARAMETERS_START)):
			active = 1;
	elif (line.lstrip().upper().startswith(PARAMETERS_END)): 
		active = 0;
	else:
		equalPos = line.find("=");
		if (equalPos >= 0):
			left = line[0 : equalPos];
			if (left.lstrip().startswith(GONZO_PREP)):
				#
				# SCALE UP THE GONZO FACTOR(S) BY DEMANDSCALE
				#
				right = line[equalPos + 1 :].lstrip();
				nextSpace = nextWhitespace(right);
				gonzo = float(right[0:nextSpace]);
				print "replacing this: ", line;
				line  = left + "=" + str(DEMANDSCALE * gonzo) + right[nextSpace:];
				print "       by this: ", line;
				print;
			elif (left.lstrip().startswith(NSTEP)):
				#
				# EXTRACT THE NUMBER OF SIMULATION PERIODS
				#
				right = line[equalPos + 1 :].lstrip();
				DEMANDPERIODS = int(right[0:nextWhitespace(right)]);
				print "identified", DEMANDPERIODS, " demand periods";
				print;
			elif (left.lstrip().startswith(TSTEP)):
				#
				# CHECK TSTEP
				#
				right = line[equalPos + 1 :].lstrip();
				value = 60 * int(right[0:nextWhitespace(right)]);
				if (value % BINSIZE == 0):
					print "OK: TSTEP", value, "s is integer multiple of BINSIZE", BINSIZE, "s";
				else:
					print "WARNING: TSTEP", value, "s is no integer multiple of BINSIZE", BINSIZE, "s";
			elif (left.lstrip().startswith(TWARM)):
				#
				# CHECK AND EXTRACT TWARM
				#
				right = line[equalPos + 1 :].lstrip();
				WARMUP = 60 * int(right[0:nextWhitespace(right)]);
				if (WARMUP % BINSIZE == 0):
					print "OK: TWARM", WARMUP, "s is integer multiple of BINSIZE", BINSIZE, "s";
				else:
					print "WARNING: TWARM", WARMUP, "s is no integer multiple of BINSIZE", BINSIZE, "s";
			elif (left.strip().startswith(TMAIN)):
				#
				# CHECK TMAIN
				#
				right = line[equalPos + 1 :].lstrip();
				value = 60 * int(right[0:nextWhitespace(right)]);
				if (value % BINSIZE == 0):
					print "OK: TMAIN", value, "s is integer multiple of BINSIZE ", BINSIZE, "s";
				else:
					print "WARNING: TMAIN", value, "s is no integer multiple of BINSIZE ", BINSIZE, "s";
	fWrite.write(line);

fWrite.close();
fRead.close();

POPULATION_FILE = "population.veh";

print;
print "------------------------------------------------------------";
print "Loading the initial demand (possibly scaled) on the network.";
print "This yields a .VEH file that is permanently stored as the";
print "driver population " + POPULATION_FILE + ", and it also yields an";
print "initial .LTT file.";
print "------------------------------------------------------------";
print;

DRACPREP_CMD = DRACPREP + " " + NETWORK;
DRACSIM_CMD  = DRACSIM  + " " + NETWORK;

shutil.copy(MODIFIED_PAR, CURRENT_PAR);
run(DRACPREP_CMD);
run(DRACSIM_CMD);
shutil.copy(NETWORK + ".veh", POPULATION_FILE);

print;
print "------------------------------------------------------------";
print "Running the iterations. The following logic is repeated";
print ITERATIONS, "times:";
print "* select a new route for every vehicle in", POPULATION_FILE;
print "* load these routes on the network";
print "* load the resulting network data and update the calibration";
print "------------------------------------------------------------";
print;

JAR_CMD    = "java -jar " + CADYTS + " "
INIT_CMD   = JAR_CMD + "INIT -logfile calibration-log.txt -statsfile calibration-stats.txt -freezeit " + str(FREEZEIT) + " -binsize " + str(BINSIZE) + " -warmup " + str(WARMUP) + " -betatt " + str(BETA_TT)+ " -minflowstddev " + str(MIN_STDDEV) + " -demandfile " + NETWORK + ".dem -flowprefix flows -ttprefix tt -initialttfile " + NETWORK + ".ltt -measfile measurements.xml -odprefix od -demandscale " + str(DEMANDSCALE) + " -demandperiods " + str(DEMANDPERIODS);
CHOICE_CMD = JAR_CMD + "CHOICE -choicesetfile " + POPULATION_FILE + " -choicefile " + NETWORK + ".veh.tmp";
UPDATE_CMD = JAR_CMD + "UPDATE -netfile " + NETWORK + ".ltt";

run(INIT_CMD);

for it in range(1, ITERATIONS + 1):
	print "ITERATION", it
	print
	run(CHOICE_CMD)
	shutil.copy(DATA_DIR + NETWORK + ".veh.tmp", DATA_DIR + NETWORK + ".veh." + str(it));
	os.remove(DATA_DIR + NETWORK + ".veh");
	os.rename(DATA_DIR + NETWORK + ".veh.tmp", DATA_DIR + NETWORK + ".veh");
	run(DRACSIM_CMD)
	run(UPDATE_CMD)

print;
print "------------------------------------------------------------";
print "DONE. Restoring original .PAR file and terminating."
print "------------------------------------------------------------";
print;

shutil.copy(ORIGINAL_PAR, CURRENT_PAR);

