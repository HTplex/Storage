/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import static cadyts.utilities.math.MathHelpers.draw;
import static cadyts.utilities.math.MathHelpers.overlap;
import static org.junit.Assert.assertEquals;

import java.util.Random;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class MathHelpersTest {

	@Test
	public void testOverlap() {
		assertEquals(0, overlap(-12.34, -1.23, 1.23, 12.34));
		assertEquals(0, overlap(-1.23, -12.34, 1.23, 12.34));
		assertEquals(0, overlap(-12.34, -1.23, 12.34, 1.23));
		assertEquals(0, overlap(-1.23, -12.34, 12.34, 1.23));

		assertEquals(5, overlap(0.5, 10.5, 5.5, 15.5));
		assertEquals(5, overlap(5.5, 15.5, 0.5, 10.5));

		assertEquals(5, overlap(Double.NEGATIVE_INFINITY, 10.5, 5.5, 15.5));
		assertEquals(5, overlap(0.5, 10.5, 5.5, Double.POSITIVE_INFINITY));

		assertEquals(9, overlap(Double.NEGATIVE_INFINITY,
				Double.POSITIVE_INFINITY, 1, 10));
		assertEquals(9, overlap(-10, -1, Double.NEGATIVE_INFINITY,
				Double.POSITIVE_INFINITY));

		assertEquals(0, overlap(Double.NEGATIVE_INFINITY,
				Double.POSITIVE_INFINITY, 10, 1));
		assertEquals(0, overlap(-1, -10, Double.NEGATIVE_INFINITY,
				Double.POSITIVE_INFINITY));
	}

	@Test
	public void testDrawStartWithZeroProb() {
		final Random r = new Random(12345);
		final Vector p = new Vector(0.0, 0.1, 0.3, 0.6);
		final Vector c = new Vector(4);

		final int draws = 1000 * 1000;
		for (int n = 0; n < draws; n++) {
			c.add(draw(p, r), 1);
		}
		c.mult(1.0 / draws);

		assertEquals(c.get(0), p.get(0), 1e-3);
		assertEquals(c.get(1), p.get(1), 1e-3);
		assertEquals(c.get(2), p.get(2), 1e-3);
		assertEquals(c.get(3), p.get(3), 1e-3);
	}

	@Test
	public void testDrawStartWithNonzeroProb() {
		final Random r = new Random(12345);
		final Vector p = new Vector(0.1, 0.1, 0.3, 0.5);
		final Vector c = new Vector(4);

		final int draws = 1000 * 1000;
		for (int n = 0; n < draws; n++) {
			c.add(draw(p, r), 1);
		}
		c.mult(1.0 / draws);

		assertEquals(c.get(0), p.get(0), 1e-3);
		assertEquals(c.get(1), p.get(1), 1e-3);
		assertEquals(c.get(2), p.get(2), 1e-3);
		assertEquals(c.get(3), p.get(3), 1e-3);
	}

	@Test
	public void testLogOfFactorial() {
		assertEquals(MathHelpers.logOfFactorial(0), 0.0);
		assertEquals(MathHelpers.logOfFactorial(1), 0.0);
		assertEquals(MathHelpers.logOfFactorial(2), Math.log(2));
		assertEquals(MathHelpers.logOfFactorial(3), Math.log(3));
	}

	@Test
	public void testLogOfMultinomialCoefficient() {
		assertEquals(MathHelpers.logOfMultinomialCoefficient(0, 0, 0), Math
				.log(1));
		assertEquals(MathHelpers.logOfMultinomialCoefficient(1, 1, 1), Math
				.log(6));
		assertEquals(MathHelpers.logOfMultinomialCoefficient(1, 2, 3), Math
				.log(60));
		assertEquals(MathHelpers.logOfMultinomialCoefficient(3, 2, 1), Math
				.log(60));
	}

	@Test
	public void overrideTest1() {
		final double[] result = MathHelpers.override(null, null, true);
		assertEquals(null, result);
	}

	@Test
	public void overrideTest2() {
		final double[] result = MathHelpers.override(null, null, false);
		assertEquals(null, result);
	}

	@Test
	public void overrideTest3() {
		final double[] dest = new double[] { -1.0, 0.0, 1.0 };
		final double[] result = MathHelpers.override(dest, null, true);
		assertEquals(null, result);
	}

	@Test
	public void overrideTest4() {
		final double[] dest = new double[] { -1.0, 0.0, 1.0 };
		final double[] result = MathHelpers.override(dest, null, false);
		assertEquals(dest, result);
		assertEquals(dest[0], result[0]);
		assertEquals(dest[1], result[1]);
		assertEquals(dest[2], result[2]);
	}

	@Test
	public void overrideTest5() {
		final double[] dest = new double[] { -1.0, 0.0, 1.0 };
		final double[] source = new double[] { 0.0, 10.0, 0.0 };
		final double[] result = MathHelpers.override(dest, source, false);
		assertEquals(dest, result);
		assertEquals(dest[0], result[0]);
		assertEquals(source[1], result[1]);
		assertEquals(dest[2], result[2]);
	}

	@Test
	public void overrideTest6() {
		final double[] dest = new double[] { -1.0, 0.0, 1, 0 };
		final double[] source = new double[] { 0.0, 10.0, 0.0 };
		final double[] result = MathHelpers.override(dest, source, true);
		assertEquals(dest, result);
		assertEquals(source[0], result[0]);
		assertEquals(source[1], result[1]);
		assertEquals(source[2], result[2]);
	}
}
