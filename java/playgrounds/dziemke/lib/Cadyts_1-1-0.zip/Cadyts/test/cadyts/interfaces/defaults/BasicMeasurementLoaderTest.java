/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.interfaces.defaults;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import cadyts.calibrators.Calibrator;
import cadyts.utilities.misc.Time;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class BasicMeasurementLoaderTest {

	private static File tmpFile;

	@BeforeClass
	public static void createFile() throws IOException {
		tmpFile = File.createTempFile("test", null);
		System.out.println("tmpFile = " + tmpFile);
		final PrintWriter w = new PrintWriter(tmpFile);
		w.println("<measurements>");
		w.println("    <onlink link=\"l3\" start=\"07:00:00\" "
				+ "end=\"08:00:00\" value=\"1000\" stddev=\"10\" "
				+ "type=\"FLOW_VEH_H\" />");
		w.println("    <onlink link=\"l3\" start=\"12345\" "
				+ "end=\"08:00:00\" value=\"1000\" stddev=\"10\" "
				+ "type=\"FLOW_VEH_H\" />");
		w.println("    <multilink value=\"10\" detectionrate=\"0.5\">");
		w.println("        <observation link=\"l1\" start=\"7:28:39\" "
				+ "end=\"7:31:21\" />");
		w.println("        <observation link=\"l2\" start=\""
				+ Time.secFromStr("7:29:00") + "\" end=\""
				+ Time.secFromStr("7:33:00") + "\"/>");
		w.println("        <observation link=\"l3\" start=\"7:35:33\" "
				+ "end=\"7:35:53\" />");
		w.println("    </multilink>");
		w.println("</measurements>");
		w.flush();
		w.close();
	}

	@Test
	public void testMeasLoading() {
		final Calibrator<String> c = new Calibrator<String>(null, null, 3600);
		final BasicMeasurementLoader<String> l = new BasicMeasurementLoaderStringLinks(
				c);
		l.load(tmpFile.toString());
	}

	@AfterClass
	public static void deleteFile() {
		tmpFile.delete();
	}

}
