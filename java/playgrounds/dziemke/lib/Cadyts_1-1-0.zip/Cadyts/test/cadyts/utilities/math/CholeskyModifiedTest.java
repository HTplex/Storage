/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */
package cadyts.utilities.math;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;

import java.util.Random;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class CholeskyModifiedTest {

	private Matrix newSymmetricRandom(final Random rnd) {
		final int dim = rnd.nextInt(10) + 1;
		final Matrix result = new Matrix(dim, dim);
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < i; j++) {
				final double x = rnd.nextGaussian();
				result.getRow(i).set(j, x);
				result.getRow(j).set(i, x);
			}
			result.getRow(i).set(i, rnd.nextDouble());
		}
		return result;
	}

	@Test
	public void testInversion() {
		final Random rnd = new Random(1979);

		for (int run = 0; run < 100; run++) {

			final Matrix _A = newSymmetricRandom(rnd);
			final CholeskyModified c = new CholeskyModified(1000);
			assertEquals(true, c.invert(_A));
			final Matrix _A_inv = c.getResult();
			// System.out.println(c.getTrials());

			assertNotNull(_A_inv);
			assertEquals(_A.rowSize(), _A_inv.rowSize());
			assertEquals(_A.columnSize(), _A_inv.columnSize());
		}
	}

	// public static void main(String[] args) {
	// (new CholeskyModifiedTest()).testInversion();
	// }
}
