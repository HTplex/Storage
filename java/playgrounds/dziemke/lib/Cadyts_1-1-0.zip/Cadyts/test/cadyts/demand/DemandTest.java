/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.demand;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import cadyts.demand.Demand;
import cadyts.demand.PlanStep;

/**
 * 
 * @author Gunnar Fl�tter�d
 *
 */
public class DemandTest {

	@Test(expected = IllegalArgumentException.class)
	public void testDemand1() {
		new Demand<String>(-1, 10, 10);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testDemand3() {
		new Demand<String>(0, 0, 10);
	}

	public void testDemand4() {
		new Demand<String>(0, 10, 10);
		// TODO this should not be allowed
		new Demand<String>(0, Integer.MAX_VALUE, 10);
		// TODO this should not be allowed
		new Demand<String>(0, 10, Integer.MAX_VALUE);
	}

	@Test
	public void testAddPlanStepOfL() {
		final Demand<Integer> d = new Demand<Integer>(0, 10, 10);
		assertTrue(d.add(new PlanStep<Integer>(1, 0)));
		assertTrue(d.add(new PlanStep<Integer>(1, 10 * 10 - 1)));
		assertFalse(d.add(new PlanStep<Integer>(1, 10 * 10)));
	}
}
