/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.calibrators.filebased.xml;

import static cadyts.calibrators.filebased.xml.TestXMLPopulationFileReaderAndHandler.AGENT;
import static cadyts.calibrators.filebased.xml.TestXMLPopulationFileReaderAndHandler.ID;

import org.xml.sax.Attributes;

import cadyts.calibrators.filebased.Agent;
import cadyts.demand.Plan;
import cadyts.demand.PlanChoiceDistribution;
import cadyts.demand.PlanChoiceModel;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class TestPopulationHandlerSubclass extends
		PopulationHandler<Agent<Plan<String>, ?>> {

	private Agent<Plan<String>, ?> tempAgent = null;

	@Override
	public void startElement(String namespaceURI, String sName, String qName,
			Attributes attrs) {
		if (AGENT.equals(qName)) {
			this.tempAgent = new Agent<Plan<String>, PlanChoiceModel<Plan<String>>>(
					attrs.getValue(ID),
					new PlanChoiceDistribution<Plan<String>>());
		}
	}

	public void endElement(String uri, String localName, String qName) {
		if (AGENT.equals(qName)) {
			this.putNextAgent(this.tempAgent);
			this.tempAgent = null;
		}
	}
}
