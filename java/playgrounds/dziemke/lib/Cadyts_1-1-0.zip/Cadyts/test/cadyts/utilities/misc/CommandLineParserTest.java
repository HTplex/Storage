/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.misc;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import cadyts.utilities.misc.CommandLineParser;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class CommandLineParserTest {

	@Test
	public void testSimple() {
		CommandLineParser clp;

		clp = new CommandLineParser();
		clp.parse(new String[] {});
		assertEquals(0, clp.size());

		clp = new CommandLineParser();
		clp.parse(new String[] { "-A", "a" });
		assertEquals(1, clp.size());
		assertEquals("a", clp.getString("-A"));

		clp = new CommandLineParser();
		clp.parse(new String[] { "-A", "a", "-B", "b" });
		assertEquals(2, clp.size());
		assertEquals("a", clp.getString("-A"));
		assertEquals("b", clp.getString("-B"));
	}

	@Test
	public void testComplexOK() {
		CommandLineParser clp = new CommandLineParser();
		clp.defineParameter("-p1", true, "defaultVal1", "1st");
		clp.defineParameter("-p2", false, "defaultVal2", "2nd");
		clp.parse(new String[] { "-p1", "value1" });
		assertEquals(2, clp.size());
		assertEquals(2, clp.getElements().size());
		assertEquals(0, clp.getMissingElements().size());
		assertEquals("value1", clp.getString("-p1"));
		assertEquals("defaultVal2", clp.getString("-p2"));
	}

	@Test
	public void testComplexNotOK() {
		CommandLineParser clp = new CommandLineParser();
		clp.defineParameter("-p1", true, null, "1st");
		clp.defineParameter("-p2", false, "defaultVal2", "2nd");
		clp.parse(new String[] { "-p2", "value2" });
		assertEquals(1, clp.size());
		assertEquals(2, clp.getElements().size());
		assertEquals(1, clp.getMissingElements().size());
		assertEquals(null, clp.getString("-p1"));
		assertEquals("value2", clp.getString("-p2"));
	}
}
