/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.measurements;

import junit.framework.Assert;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class MeasurementTest {

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction1() {
		new SingleLinkMeasurement<String>("link", Double.POSITIVE_INFINITY, 1,
				0, 3600, SingleLinkMeasurement.TYPE.FLOW_VEH_H);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction2() {
		new SingleLinkMeasurement<String>("link", 1, -1, 0, 3600,
				SingleLinkMeasurement.TYPE.FLOW_VEH_H);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstruction3() {
		new SingleLinkMeasurement<String>("link", 1, 1, 0, 3600, null);
	}

	@Test
	public void testSimpleGetters() {
		final SingleLinkMeasurement<Integer> m = new SingleLinkMeasurement<Integer>(
				4711, 1, 2, 0, 3600, SingleLinkMeasurement.TYPE.FLOW_VEH_H);
		Assert.assertEquals(0, m.getStartTime_s());
		Assert.assertEquals(3600, m.getEndTime_s());
		Assert.assertEquals(3600, m.getDuration_s());
		Assert.assertEquals(new Integer(4711), m.getLink());
		Assert.assertEquals(1.0, m.getMeasValue());
		Assert.assertEquals(2.0, m.getMeasVariance());
		Assert.assertEquals(Math.sqrt(2), m.getMeasStddev());
		Assert.assertEquals(SingleLinkMeasurement.TYPE.FLOW_VEH_H, m.getType());
	}

	@Test
	public void testLLEvaluation() {
		final SingleLinkMeasurement<String> m = new SingleLinkMeasurement<String>(
				"link", 0, 1, 0, 3600, SingleLinkMeasurement.TYPE.FLOW_VEH_H);
		Assert.assertEquals(-0.5, m.ll(-1));
		Assert.assertEquals(-0.5, m.ll(1));
	}
}
