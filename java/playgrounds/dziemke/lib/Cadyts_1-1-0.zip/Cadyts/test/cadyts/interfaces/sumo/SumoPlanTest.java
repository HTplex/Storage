/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.interfaces.sumo;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import cadyts.utilities.misc.DynamicData;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class SumoPlanTest {

	@Test
	public void testSumoPlan1() {
		final List<String> edges = new ArrayList<String>(3);
		final List<Integer> exits = new ArrayList<Integer>(3);
		final int start_s = 0;
		edges.add("1");
		exits.add(5);
		edges.add("2");
		exits.add(10);
		edges.add("3");
		exits.add(15);
		final SumoPlan plan = new SumoPlan(1, start_s, edges, exits, null);
		Assert.assertEquals(2, plan.size());
		Assert.assertEquals("1", plan.getStartLink());
		Assert.assertEquals(5, plan.getStep(0).getEntryTime_s());
		Assert.assertEquals("2", plan.getStep(0).getLink());
		Assert.assertEquals(10, plan.getStep(1).getEntryTime_s());
		Assert.assertEquals("3", plan.getStep(1).getLink());
		Assert.assertEquals(15, plan.getExitTime_s());
	}

	@Test
	public void testSumoPlan2a() {
		final int binStart = 0;
		final int binSize = 8;
		final int binCnt = 2;
		final DynamicData<String> tt = new DynamicData<String>(binStart,
				binSize, binCnt);
		tt.put("1", 0, 9.0);
		tt.put("1", 1, 8.0);
		tt.put("2", 0, 6.0);
		tt.put("2", 1, 5.0);
		tt.put("3", 0, 3.0);
		tt.put("3", 1, 2.0);
		final List<String> edges = new ArrayList<String>(1);
		final List<Integer> exits = new ArrayList<Integer>(1);
		final int start_s = 0;
		edges.add("1");
		exits.add(5);
		final SumoPlan plan = new SumoPlan(1, start_s, edges, exits, tt);
		Assert.assertEquals(0, plan.size());
		Assert.assertEquals("1", plan.getStartLink());
		Assert.assertEquals(5, plan.getExitTime_s());
	}
	
	@Test
	public void testSumoPlan2b() {
		final int binStart = 0;
		final int binSize = 8;
		final int binCnt = 2;
		final DynamicData<String> tt = new DynamicData<String>(binStart,
				binSize, binCnt);
		tt.put("1", 0, 9.0);
		tt.put("1", 1, 8.0);
		tt.put("2", 0, 6.0);
		tt.put("2", 1, 5.0);
		tt.put("3", 0, 3.0);
		tt.put("3", 1, 2.0);
		final List<String> edges = new ArrayList<String>(3);
		final List<Integer> exits = new ArrayList<Integer>(3);
		final int start_s = 0;
		edges.add("1");
		exits.add(5);
		edges.add("2");
		exits.add(10);
		final SumoPlan plan = new SumoPlan(1, start_s, edges, exits, tt);
		Assert.assertEquals(1, plan.size());
		Assert.assertEquals("1", plan.getStartLink());
		Assert.assertEquals(9, plan.getStep(0).getEntryTime_s());
		Assert.assertEquals("2", plan.getStep(0).getLink());
		Assert.assertEquals(14, plan.getExitTime_s());
	}	
	
	@Test
	public void testSumoPlan2c() {
		final int binStart = 0;
		final int binSize = 8;
		final int binCnt = 2;
		final DynamicData<String> tt = new DynamicData<String>(binStart,
				binSize, binCnt);
		tt.put("1", 0, 9.0);
		tt.put("1", 1, 8.0);
		tt.put("2", 0, 6.0);
		tt.put("2", 1, 5.0);
		tt.put("3", 0, 3.0);
		tt.put("3", 1, 2.0);
		final List<String> edges = new ArrayList<String>(3);
		final List<Integer> exits = new ArrayList<Integer>(3);
		final int start_s = 0;
		edges.add("1");
		exits.add(5);
		edges.add("2");
		exits.add(10);
		edges.add("3");
		exits.add(15);
		final SumoPlan plan = new SumoPlan(1, start_s, edges, exits, tt);
		Assert.assertEquals(2, plan.size());
		Assert.assertEquals("1", plan.getStartLink());
		Assert.assertEquals(9, plan.getStep(0).getEntryTime_s());
		Assert.assertEquals("2", plan.getStep(0).getLink());
		Assert.assertEquals(14, plan.getStep(1).getEntryTime_s());
		Assert.assertEquals("3", plan.getStep(1).getLink());
		Assert.assertEquals(19, plan.getExitTime_s());
	}	
}
