/*
 * Cadyts - Calibration of dynamic traffic simulations
 *
 * Copyright 2009, 2010 Gunnar Fl�tter�d
 * 
 *
 * This file is part of Cadyts.
 *
 * Cadyts is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cadyts is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cadyts.  If not, see <http://www.gnu.org/licenses/>.
 *
 * contact: gunnar.floetteroed@epfl.ch
 *
 */ 
package cadyts.utilities.math;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Test;

/**
 * 
 * @author Gunnar Fl�tter�d
 * 
 */
public class VectorTest {

	@Test(expected = IllegalArgumentException.class)
	public void testVectorConstructionInt() {
		new Vector(0);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testVectorConstructionInt2() {
		new Vector(-1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testVectorConstructionDoubleArray() {
		new Vector();
	}

	@Test(expected = IllegalArgumentException.class)
	public void testVectorConstructionArray() {
		final double[] data = null;
		new Vector(data);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testVectorConstructionList1() {
		final List<Double> data = null;
		new Vector(data);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testVectorConstructionList2() {
		final List<Double> data = new ArrayList<Double>(0);
		new Vector(data);
	}

	@Test
	public void testVectorConstructionList3() {
		final List<Double> data = new ArrayList<Double>(3);
		data.add(-1.1);
		data.add(0.0);
		data.add(2.2);
		final Vector v = new Vector(data);
		assertEquals(3, v.size());
		assertEquals(-1.1, v.get(0));
		assertEquals(0.0, v.get(1));
		assertEquals(2.2, v.get(2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testVectorConstructionArray2() {
		new Vector(new double[] {});
	}

	@Test(expected = IllegalArgumentException.class)
	public void testVectorConstructionArray3() {
		new Vector();
	}

	@Test
	public void testVectorInt() {
		assertEquals(5, (new Vector(5).size()));
	}

	@Test
	public void testVectorDoubleArray() {
		final Vector result = new Vector(1, 2, 3);
		assertEquals(3, result.size());
		assertEquals(1, result.get(0));
		assertEquals(2, result.get(1));
		assertEquals(3, result.get(2));
	}

	@Test
	public void testVectorIntRandom() {
		Vector result = Vector.newGaussian(3);
		assertEquals(3, result.size());

		result = Vector.newGaussian(3, null);
		assertEquals(3, result.size());

		result = Vector.newGaussian(3, new Random());
		assertEquals(3, result.size());
	}

	@Test
	public void testCopy() {
		final Vector expected = new Vector(.1, .2, .3);
		final Vector clone = expected.copy();
		assertFalse(expected == clone);
		assertEquals(expected.size(), clone.size());
		assertEquals(expected.get(0), clone.get(0));
		assertEquals(expected.get(1), clone.get(1));
		assertEquals(expected.get(2), clone.get(2));
	}

	@Test
	public void testInnerProd() {
		final Vector v1 = new Vector(0.5, 2, +3);
		final Vector v2 = new Vector(3, 0.5, -1);
		assertEquals(-.5, v1.innerProd(v2));
		assertEquals(-.5, v2.innerProd(v1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testInnerProd2() {
		(new Vector(1.0, 2.0)).innerProd(new Vector(1.0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testInnerProd3() {
		(new Vector(-0.0)).innerProd(new Vector(1.0, Double.MIN_VALUE));
	}

	@Test
	public void testAddVectorDouble() {
		final Vector v1 = new Vector(-1, 2);
		final Vector v2 = new Vector(.1, .1);
		v1.add(v2, 5);
		assertEquals(0.5, v1.get(0));
		assertEquals(2.5, v1.get(1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddVectorDouble2() {
		(new Vector(-0.0)).add(new Vector(1.0, Double.MIN_VALUE), 1.0);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddVectorDouble3() {
		(new Vector(1.0, 2.0)).add(new Vector(1.0), -1);
	}

	@Test
	public void testClear() {
		final Vector v1 = new Vector(-1.0, 0, 1.0);
		v1.clear();
		assertEquals(0, v1.get(0));
		assertEquals(0, v1.get(1));
		assertEquals(0, v1.get(2));
	}

	@Test
	public void testEuclNorm() {
		assertEquals(Math.sqrt(2), (new Vector(-1, 1)).euclNorm());
	}

	@Test
	public void testNormalize() {
		final Vector v = new Vector(1.312, -.1243, -2.2314, .0123);
		v.normalize();
		assertEquals(1, v.euclNorm());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testEnlarge1() {
		(new Vector(1.0, 2.0, 3.0)).copyEnlarged(-1);
	}

	@Test
	public void testEnlarge2() {
		final Vector original = new Vector(1.0, 2.0, 3.0);

		Vector copy = original.copy();
		assertEquals(original.size(), copy.size());
		assertEquals(original.get(0), copy.get(0));
		assertEquals(original.get(1), copy.get(1));
		assertEquals(original.get(2), copy.get(2));

		copy = original.copyEnlarged(2);
		assertEquals(original.size() + 2, copy.size());
		assertEquals(original.get(0), copy.get(0));
		assertEquals(original.get(1), copy.get(1));
		assertEquals(original.get(2), copy.get(2));
	}

	@Test
	public void testRound1() {
		final Vector v = new Vector(0.0, 1.2, 3.45, 6.789);
		v.round(3);
		assertEquals(0.000, v.get(0));
		assertEquals(1.200, v.get(1));
		assertEquals(3.450, v.get(2));
		assertEquals(6.789, v.get(3));
		v.round(2);
		assertEquals(0.00, v.get(0));
		assertEquals(1.20, v.get(1));
		assertEquals(3.45, v.get(2));
		assertEquals(6.79, v.get(3));
		v.round(1);
		assertEquals(0.0, v.get(0));
		assertEquals(1.2, v.get(1));
		assertEquals(3.5, v.get(2));
		assertEquals(6.8, v.get(3));
		v.round(0);
		assertEquals(0.0, v.get(0));
		assertEquals(1.0, v.get(1));
		assertEquals(4.0, v.get(2));
		assertEquals(7.0, v.get(3));
	}

	@Test
	public void testRound2() {
		final Vector v = new Vector(0.0, 12.0, 345.0, 6789.0);
		v.round(0);
		assertEquals(0000.0, v.get(0));
		assertEquals(0012.0, v.get(1));
		assertEquals(0345.0, v.get(2));
		assertEquals(6789.0, v.get(3));
		v.round(-1);
		assertEquals(0000.0, v.get(0));
		assertEquals(0010.0, v.get(1));
		assertEquals(0350.0, v.get(2));
		assertEquals(6790.0, v.get(3));
		v.round(-2);
		assertEquals(0000.0, v.get(0));
		assertEquals(0000.0, v.get(1));
		assertEquals(0400.0, v.get(2));
		assertEquals(6800.0, v.get(3));
		v.round(-3);
		assertEquals(0000.0, v.get(0));
		assertEquals(0000.0, v.get(1));
		assertEquals(0000.0, v.get(2));
		assertEquals(7000.0, v.get(3));
		v.round(-4);
		assertEquals(00000.0, v.get(0));
		assertEquals(00000.0, v.get(1));
		assertEquals(00000.0, v.get(2));
		assertEquals(10000.0, v.get(3));
		v.round(-5);
		assertEquals(0.0, v.get(0));
		assertEquals(0.0, v.get(1));
		assertEquals(0.0, v.get(2));
		assertEquals(0.0, v.get(3));
	}

	@Test
	public void testAbsValueSum1() {
		final Vector x = new Vector(-1.0);
		assertEquals(1.0, x.absValueSum());
	}

	@Test
	public void testAbsValueSum2() {
		final Vector x = new Vector(-1.0, 1.0);
		assertEquals(2.0, x.absValueSum());
	}

	@Test
	public void testAbsValueSum3() {
		final Vector x = new Vector(-1.0, -1.0);
		assertEquals(2.0, x.absValueSum());
	}

	@Test
	public void testMin() {
		Vector x = new Vector(0.0);
		assertEquals(x.min(), 0.0);

		x = new Vector(-1.4);
		assertEquals(x.min(), -1.4);

		x = new Vector(1.2);
		assertEquals(x.min(), 1.2);

		x = new Vector(-1.1, 1.1);
		assertEquals(x.min(), -1.1);

		x = new Vector(0, 2.3);
		assertEquals(x.min(), 0.0);

		x = new Vector(-0.5, -1.1);
		assertEquals(x.min(), -1.1);

		x = new Vector(1.2, 0.0);
		assertEquals(x.min(), 0.0);

		x = new Vector(-0.5, -1.1);
		assertEquals(x.min(), -1.1);

		x = new Vector(1.2, 0.0, 2.3);
		assertEquals(x.min(), 0.0);
	}

	@Test
	public void testMax() {
		Vector x = new Vector(0.0);
		assertEquals(x.max(), 0.0);

		x = new Vector(1.4);
		assertEquals(x.max(), 1.4);

		x = new Vector(-1.2);
		assertEquals(x.max(), -1.2);

		x = new Vector(1.1, -1.1);
		assertEquals(x.max(), 1.1);

		x = new Vector(0, -2.3);
		assertEquals(x.max(), 0.0);

		x = new Vector(0.5, 1.1);
		assertEquals(x.max(), 1.1);

		x = new Vector(-1.2, -0.0);
		assertEquals(x.max(), 0.0);

		x = new Vector(0.5, 1.1);
		assertEquals(x.max(), 1.1);

		x = new Vector(-1.2, 0.0, -2.3);
		assertEquals(x.max(), 0.0);
	}

	@Test
	public void testSum() {
		assertEquals(0.0, new Vector(0.0).sum());
		assertEquals(1.2, new Vector(1.2).sum());
		assertEquals(-3.4, new Vector(-3.4).sum());
		assertEquals(-2.2, new Vector(1.2, -3.4).sum());
	}

	@Test
	public void testToString() {
		assertEquals("[ -1.0 0.0 1.0 ]", (new Vector(-1.0, 0, 1.0)).toString());
	}

	@Test
	public void testEnforceBounds() {
		Vector x = new Vector(-1.0, 2.0);
		x.enforceBounds(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
		assertEquals(x.get(0), -1.0);
		assertEquals(x.get(1), 2.0);
		x.enforceBounds(-0.1, 0.2);
		assertEquals(x.get(0), -0.1);
		assertEquals(x.get(1), 0.2);
	}

	@Test
	public void testNewImmutableView() {
		Vector x = new Vector(-1.2, 3.4);
		assertFalse(x.isImmutable());
		assertTrue(x.newImmutableView().isImmutable());
	}

	@Test(expected = UnsupportedOperationException.class)
	public void testCheckImmutable() {
		Vector x = (new Vector(-1.2, 3.4)).newImmutableView();
		x.set(0, 5.6);
	}

	@Test
	public void testCopyVector() {
		Vector x = new Vector(-1.2, 3.4);
		Vector y = new Vector(x.size());
		y.copy(x);
		assertFalse(x == y);
		assertEquals(x.size(), y.size());
		assertEquals(x.get(0), y.get(0));
		assertEquals(x.get(1), y.get(1));
	}

	@Test
	public void testIsAllZeros1() {
		Vector x = new Vector(-1.2, 3.4);
		assertFalse(x.isAllZeros());
	}

	@Test
	public void testIsAllZeros2() {
		Vector x = new Vector(-0.0, 3.4);
		assertFalse(x.isAllZeros());
	}

	@Test
	public void testIsAllZeros3() {
		Vector x = new Vector(-0.0, 0.0);
		assertTrue(x.isAllZeros());
	}
}
